A *shot glass* is a glass designed to hold or measure spirits or liquor, which is either drank straight from the glass or poured into a [[Cocktails|cocktail]]. They are often decorated and come in various shapes and sizes.
In the Netherlands, a standard shot is 35ml. In this notebook, that is the standard shot size that will be used.

#Utensil