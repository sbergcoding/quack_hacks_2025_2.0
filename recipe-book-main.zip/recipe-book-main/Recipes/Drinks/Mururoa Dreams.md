# Ingredients
- 1 shot [[Blue Curaçao|blue curaçao]]
- 2 shots [[Kontiki|kontiki]]
- 1 shot [[Bacardi Blanca|bacardi blanca]]
- Ice
# Notes
- 1 servings
- Requirements: [[Tumbler]]
- Contains 25.0% ABV
# Directions
1. Mix the blue curaçao, kontiki, and bacardi blanca.
2. Serve over ice.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 