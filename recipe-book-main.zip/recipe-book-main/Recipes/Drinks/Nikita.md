# Ingredients
- 2/3 shot [[Cointreau|cointreau]]
- 1/3 shot [[Vodka|vodka]]
# Notes
- 1 serving
- Requirements: [[Shot Glass|shot glass]]
- Contains 39.18% ABV
# Directions
1. Mix the cointreau and the vodka.
2. Shake well with ice.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 