# Ingredients
- 45ml [[Rye Whiskey|rye whiskey]] or [[Bourbon|bourbon]]
- 25ml [[Butterscotch Schnapps|butterscotch schnapps]]
- 1 tsp [[Lemon|lemon juice]]
- 3 drops [[Bitters|bitters]]
- 60ml [[Seltzer|plain seltzer]]
- 120ml [[Cream Soda|cream soda]]
- 1 [[Lemon|lemon slices]]
# Notes
- 1 serving
- Requirements: None
- Time: 2 minutes
# Directions
1. Fill 2 frosted mugs about halfway with ice.
2. Add the rye/bourbon, schnapps, lemon juice, and bitters. Blend and chill.
3. Add the seltzer and the cream soda. Blend.
4. Garnish with a lemon slice, and serve.

#Source/DnD #Course/Drink #Course/Drink/Alcoholic #Diet/Vegan 