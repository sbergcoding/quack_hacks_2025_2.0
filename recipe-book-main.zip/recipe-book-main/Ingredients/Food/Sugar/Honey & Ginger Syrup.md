# Ingredients
- 100g [[Ginger|ginger]]
- 1 cup [[Honey|honey]]
- 1 cup water
# Notes
- X servings
- Requirements: saucepan
- Time: 
# Directions
1. Peel and thinly slice the ginger, and place in a saucepan. Add the honey and the water.
2. Bring to a boil, then reduce heat. Simmer for 5 minutes. Cool in a refrigerator in a sealed container for 12 hours.
3. Strain, bottle, and store refrigerated.
> [!warning] Keeps for 3 days.

#Course/Ingredient #TypeOfFood/Syrup #Diet/Vegetarian #Diet/Vegan  