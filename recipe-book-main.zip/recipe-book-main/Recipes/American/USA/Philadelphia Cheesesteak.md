# Ingredients
- 1 lb [[Ribeye Steak|ribeye steak]], trimmed and thinly sliced
- 1/2 tsp [[Salt|sea salt]]
- 1/2 tsp [[Black Pepper|black pepper]]
- 1 [[Sweet Onion|sweet onion]], large, diced
- 8 slices [[Provolone Cheese|provolone cheese]]
- 4 [[Hoagie Rolls|hoagie rolls]], sliced 3/4 through
- 2 tbsp [[Unsalted Butter|unsalted butter]]
- 1 clove [[Garlic|garlic]], pressed
- 2-4 tbsp [[Mayonnaise|mayonnaise]]
# Notes
- 4 servings
- Requirements:
- Time: 
# Directions
1. In a small bowl, stir together the softened butter with the garlic. Spread the garlic butter onto the cut sides of the roll.
2. Toast the buns on a large skillet on medium heat, until golden brown. Set aside.
3. Add 1 tbsp oil to the pan, and sauté diced onions until caramelised, then transfer to a bowl.
4. Increase to high heat, and add 1 tbsp oil. Spread the super thinly sliced steak in an even layer. Let brown for a couple of minutes, undisturbed. Then flip and season with salt and pepper. Stir in the caramelised onions.
5. Divide into even portions, and top each with 2 slices of cheese. Turn off the heat so the cheese will melt without overcooking the meat.
6. Spread a thin layer of mayonnaise on the toasted side of each roll. Working with one portion at a time, place a toasted bun over each portion, and use a spatula to scrape the cheesy beef into your bun as you flip it over.
#Cuisine/American/USA  #Source/NatashasKitchen #Course/Lunch #TypeOfFood/Sandwich #Diet/Meat/Beef  