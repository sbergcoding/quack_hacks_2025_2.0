# Ingredients
- 1/2 shot [[Pisang Ambon|pisang ambon]]
- 1/2 shot [[Coebergh|coebergh]]
- [[Orange Juice|orange juice]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 2.37% ABV
# Directions
1. Mix the pisang ambon with the coebergh.
2. Top up with orange juice.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 