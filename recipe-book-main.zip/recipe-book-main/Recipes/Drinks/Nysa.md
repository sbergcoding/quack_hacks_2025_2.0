# Ingredients
- 1/2 shot [[Jenever]]
- 1/2 shot [[Blue Curaçao]]
- [[Fanta]]
# Notes
- 1 serving
- Requirements: [[Tumbler]]
- Contains 3.3% ABV
# Directions
1. Mix the Ketel1 and blue curaçao.
2. Top up with fanta.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 