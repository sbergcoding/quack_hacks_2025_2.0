*Limoncello* is an Italian lemon-based liquor. It is used as a digestif, primarily served after dinner at very cold temperatures. 
It is also popular in [[Cocktails|cocktails]], and among students, as a [[Mixed Drinks|mixer]].

Limoncello contains an ABV of 25% to 36%.

#Ingredient 