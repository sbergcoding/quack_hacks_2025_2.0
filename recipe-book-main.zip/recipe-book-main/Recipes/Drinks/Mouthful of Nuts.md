# Ingredients
- 1 shot [[Frangelico|frangelico]]
- 1 shot [[Amaretto|amaretto]]
- 1 shot [[Baileys|baileys]]
# Notes
- 1 serving
- Requirements: [[Tumbler|tumbler]]
- Contains ?? ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/KarpeNoktem #Diet/Vegetarian 