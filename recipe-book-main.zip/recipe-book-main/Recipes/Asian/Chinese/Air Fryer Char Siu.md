# Ingredients
- 2 lbs of [[Pork Butt|pork butt]] or [[Pork Shoulder|shoulder]]
- 1 inch of [[Fresh Ginger|ginger]]
- 2 cloves of [[Garlic|garlic]]
- 4 tbsp [[Char Siu sauce|char siu sauce]]
- 1 tbsp [[Five Spices blend|five spices powder]]
- 1 tsp [[White Pepper|white pepper]]
- 1 tbsp [[Light Soy Sauce|light soy sauce]]
- *[[Honey]], for glazing*
# Directions
1. Place pork butt into a mixing bowl, and incorporate the ginger, garlic, char siu sauce, fie spice powder, white pepper powder, and soy sauce.
2. Marinate overnight.
3. Preheat oven to 400F.
4. Cook for 15 minutes. Check in every 2-3 minutes to flip the pork *and to baste with the honey.*	
#Cuisine/Asian #Course/Side #Diet/Meat/Pork 