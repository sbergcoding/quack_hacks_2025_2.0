# Ingredients
- 1/2 shot [[DropShot|dropshot]]
- 1/2 shot [[Pisang Ambon|pisang ambon]]
# Notes
- 1 serving
- Requirements: [[Shot Glass|shot glass]]
- Contains 20.5% ABV
# Directions
1. Mix ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan