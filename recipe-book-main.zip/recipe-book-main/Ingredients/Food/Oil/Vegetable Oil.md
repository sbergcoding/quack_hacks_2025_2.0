 Corn or soybean oil. Vegetable oils have a high smoke point, and are ideal for stirfrying, roasting, or baking.

- Good for stir-frying and sauteing
- Good for roasting
- Good for baking

#Ingredient 

[[TODO]]