# Ingredients
- 1/2 shot [[Pisang Ambon|pisang ambon]]
- 1/2 shot [[Sperm|sperm]]
# Notes
- 1 serving
- Requirements: [[Shot Glass|shot glass]], 1 willing man
- Contains 18.0% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegetarian 