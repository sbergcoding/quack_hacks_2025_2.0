*Apfelkorn* is a popular German liquor based on [[Apple|apples]]. It is primarily made by the Berentzen company. It is generally drank either pure or with ice, but it is also a popular [[Mixed Drinks|mixer]]. 

There are a couple of variants of apfelkorn:
- SaurerApfel is made out of the more sour [[Granny Smith|granny smith]] variant of apple, and is therefore more sour than regular apfelkorn. This contains 16% ABV.
- Winterapfel is the winter variant, which contains extra spices, and is also drinkable warm (as long as it hasn’t been boiled). This contains 18% ABV.
- Peerkorn is made with [[Pear|pears]] instead of apples. It contains 15% ABV.

Apfelkorn contains an ABV of 14.5%.

#Ingredient 