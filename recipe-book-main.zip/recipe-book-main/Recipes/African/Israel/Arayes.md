# Ingredients
- 500g [[Minced Meat|minced meat]]
- 4 [[Garlic|garlic cloves]] (minced)
- 150g [[Parsley|parsley]] (finely chopped)
- 1 [[Yellow Onion|yellow onion]] (finely diced)
- 1 [[Jalapeño|jalapeño]]
- 1 tsp [[Ginger|ground ginger]]
- 1 tsp [[Green Cardamon|ground green cardamon]]
- 1 tbsp [[Black Pepper|black pepper]]
- 1/2 tbsp [[Salt|salt]]
- 1 tsp [[Garlic Powder|garlic powder]]
- 1 tsp [[Onion Powder|onion powder]]
- 1/2 tsp [[Nutmeg|nutmeg]]
- 2 tsp [[Allepo Chili Pepper|allepo Chili Pepper]]
- 1 tsp [[Paprika|smoked paprika]]
- 2 tsp [[Olive Oil|olive oil]]
- 200g [[Yogurt|greek yogurt]]
- [[Pita Bread|pita bread]]

# Notes
- 3 people 
- Requirements: Grill pan, oven, cutting board
- Time: ± 45 minutes to an hour
# Directions
1. Make your filling by combining the minced meat, 3 garlic cloves, 100g parsley, the onion, jalapeño, ginger, cardamon, garlic powder, onion powder, nutmeg and Aleppo chili pepper in a large bowl. Mix well, and rest in the fridge for at least 30 minutes.
2. Make your dipping sauce by combining the yogurt, 50g parsley, 1/2 tsp salt, 1 tsp black pepper, 1 tbsp olive oil, and 1 garlic clove. Mix well, and rest in the fridge for at minimum 30 minutes.
3. Slice your pita bread in half and gently open them up, fill them up with the mixture, and set aside. 
4. Heat up a grill pan and oil well, and heat well. Add the arayes one by one and cook for roughly 30 seconds on each side. 
5. Once seared nicely, remove and place in a preheated oven at 180C and bake for 10 minutes until the meat is fully cooked and the bread is crispy. 
#Cuisine/African/Palestinian #Course/Side #TypeOfFood/Sandwich #Diet/Meat 