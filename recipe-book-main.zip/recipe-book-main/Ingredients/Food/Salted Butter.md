*Salted butter* is, predictably, the [[Salt|salted]] equivalent of [[Unsalted Butter|unsalted butter]]. Its primary use is as a condiment or as a garnish, as the salt content will throw off most recipes when unaccounted for. For example, too much salt toughens the gluten in flour.
When used as a spread or condiment, care should be taken that it is taken out of the refrigerator about 30 minutes beforehand, so it can soften up. When fresh out of the fridge, it is often too hard to use properly.

#Ingredient 