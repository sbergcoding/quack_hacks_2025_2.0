# Ingredients
- 1/2 shot [[Grand Marnier|grand marnier]]
- 1/2 shot [[Café Marrakesh|Café Marrakesh]]
- 1 shot [[Malibu Rum|malibu rum]]
- [[Chocolate Milk|Chocolate milk]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 7.00% ABV
# Directions
1. Mix the grand marnier, café marrakesh, and malibu rum.
2. Top up with chocolate milk.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegetarian 