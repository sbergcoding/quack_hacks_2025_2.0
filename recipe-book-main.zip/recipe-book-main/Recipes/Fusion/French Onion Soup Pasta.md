# Ingredients
- 800g [[Yellow Onion|yellow onions]]
- 20g [[Butter|butter]]
- 1 tbsp [[Olive Oil|olive oil]]
- 3 cloves [[Garlic|garlic]]
- 3 tbsp [[Cognac|cognac]]
- 200ml [[Beef Stock|beef stock]]
- 500ml boiling water
- 300g [[Pasta|pasta]]
- 200g [[Cheese|gruyere]]
- *10g [[Chives|chives]]*
- Fresh [[Thyme|thyme]], [[Parsley|parsley]], [[Oregano|oregano]] and [[Sweet Basil|basil]]
# Notes
- 3 servings
- Requirements:
- Time: 
# Directions
1. Cut the onion into thin rings. Heat the butter and oil in a skillet, and caramelise the onions on medium heat (~40 minutes)
2. Meanwhile, finely mince the garlic, and remove the leaves from the herbs. In the last 5 minutes of caramelisation, add the garlic, herbs, and cognac.
3. Mix the beef stock and boiling water, and add the pasta. Put to boil for 20 minutes.
4. Meanwhile, grate the cheese. In the last 5 minutes of boiling the pasta, divide the cheese over the pasta, and cook uncovered for 5 more minutes.
5. Serve, *garnished with chives*.
#Cuisine/Fusion #Source/Allerhande #Course/Main #TypeOfFood/Pasta #Diet/Meat #Diet/Vegetarian  