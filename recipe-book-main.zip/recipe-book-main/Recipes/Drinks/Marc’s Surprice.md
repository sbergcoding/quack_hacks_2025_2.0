# Ingredients
- 1 shot [[Kontiki|kontiki]]
- 1 shot [[Pisang Ambon|pisang ambon]]
- 1 shot [[Amaretto|amaretto]]
- 1 shot [[Orange Juice|orange juice]]
# Notes
- 1 serving 
- Requirements: [[Tumbler|tumbler]]
- Contains 18.25% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 