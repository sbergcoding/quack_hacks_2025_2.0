# Ingredients
- 1 shot [[Cointreau|cointreau]]
- 1 shot [[Kontiki|kontiki]]
- [[Apple juice|Apple juice]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 8.53% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 