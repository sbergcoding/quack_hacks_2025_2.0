*Muscovado sugar* is a variant of [[Brown Sugar|natural brown sugar]] that is made by refining sugarcane with lime, but not centrifuging it. Because of this, impurities like dirt and ash are removed, but the [[Molasses|molasses]] remains within the sugar crystals. 
Muscovado sugar is deeply brown-coloured, and brings a moist texture and robust flavour to drinks and confections.

#Ingredient 

[[TODO]]