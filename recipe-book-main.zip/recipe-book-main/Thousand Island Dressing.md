# Ingredients
- 1 cup [[Mayonnaise|mayonnaise]]
- 1/4 cup [[Ketchup]]
- 1/4 cup [[Sweet Pickle Relish|sweet pickle relish]]
- 1 tsp [[Worcestershire Sauce|worcestershire sauce]]
- 1 tsp [[Horseradish|horseradish]]
- 1/2 tsp [[Paprika]]
# Notes
- 12 servings
- Requirements: bowl
- Time: ± 5 minutes
# Directions
1. Combine the ingredients in a bowl, and mix well. Cover with plastic wrap, and chill before serving.
#Cuisine/American/USA  #Source/AllRecipes  #Course/Dressing #TypeOfFood/Dressing #Diet/Vegetarian 