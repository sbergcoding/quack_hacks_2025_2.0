# Ingredients
- 1 shot [[Jameson]]
- 1 shot [[Hail & THunder|hail & thunder]]
- 1 shot [[Stroh-80|stroh-80]]
# Notes
- 1 serving
- Requirements: [[Tumbler|tumbler]]
- Contains 48.33%ABV
# Directions
1. Mix the ingredients.
#Course/Drink  #Course/Drink/Alcoholic  #Source/DeBolk  #Diet/Vegan  