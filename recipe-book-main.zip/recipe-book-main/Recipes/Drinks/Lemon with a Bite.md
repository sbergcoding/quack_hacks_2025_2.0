# Ingredients
- 1/2 shot [[Jameson|Jameson]]
- 1/2 shot [[Martini|martini]]
- 1 sour candy
# Notes
- 1 serving
- Requirements: [[Tumbler]]
- Contains 27.5% ABV
# Directions
1. Mix the Jameson and martini.
2. Add the sour candy.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 
