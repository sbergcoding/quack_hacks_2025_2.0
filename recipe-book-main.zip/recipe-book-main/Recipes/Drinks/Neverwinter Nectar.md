# Ingredients
- 2 [[Orange|oranges]]
- 1 [[Lemon]]
- 3 tbsp [[Sugar|sugar]]
- 1/2 cup [[Brandy|brandy]]
- 750ml [[White Wine|dry white wine]]
- 1 [[Apple|apple]]
- 1 cup [[Seltzer]]
- 1 cup [[Ice|ice]]
# Notes
- 8 glasses, roughly (1.6L)
- Requirements:
- Time: 
# Directions
1. Quarter one of the oranges and the lemon, cutting them from the stem end to the blossom end. Cut the quarters into thin slices, and place in a container.
2. Add the sugar, stir, and set aside until the fruit softens a little, about 20 minutes.
3. Using a muddler, mash and muddle the mixture until the fruit releases its juice, the skins are bruised, and the juices and sugar become syrupy.
4. Add the apple juice, brandy, and wine; stir; cover and refrigerate for at least 4 hours.
5. Strain the mixture into a large bowl. Pour the liquid into a serving pitcher.
6. Quarter the remaining orange, and slice the quarters crosswise. Quarter and core the apple, and thinly slice the quarters crosswise.
7. Add the orange, apple, seltzer, and ice cubes to the pitcher, and stir to blend.
8. Serve over ice.
#Source/DnD #Course/Drink #Course/Drink/Alcoholic #Diet/Vegan 