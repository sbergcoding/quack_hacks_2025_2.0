# Ingredients
- 1 shot [[Vodka|vodka]]
- 1/2 shot [[Lime Juice|lime juice]]
- [[Ginger Ale|Ginger ale]]
- Drop of [[Bitters|bitters]]
- Sprig of [[Mint|mint]]
# Notes
- 1 serving 
- Requirements: [[Tumbler|tumbler]]
- Contains 5.0% ABV
# Directions
1. Mix the vodka and the lime juice.
2. Top up with ginger ale.
3. Add a couple of drops of bitters, and garnish with a sprig of mint.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 