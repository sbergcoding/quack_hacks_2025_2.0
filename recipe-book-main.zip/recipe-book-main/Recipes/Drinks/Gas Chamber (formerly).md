# Ingredients
- 1 shot [[Sambuca|sambuca]]
- 1 drop of [[Blue Curaçao|blue curaçao]]
# Notes
- 1 serving
- Requirements: Lighter, [[Tumbler]], chaser shot 
- Contains XX% ABV
# Directions
1. Add the shot of sambuca and the drop of blue curaçao to the tumbler glass.
2. Use the lighter to ignite the alcohol in the mix.
3. Let burn for a couple of seconds.
4. *Moisten hand* and extinguish the fire, holding the hand over the glass for as much as possible.
5. Lightly shake the tumbler to mix the drinks.
## *Suggested Drinking Directions*
1. Take the chaser shot.
2. Take a whiff of the alcohol vapours coming from the main mixture.
3. Drink the rest.
 #Source/Biton #Course/Drink/Alcoholic #Course/Drink #Diet/Vegan 