# Ingredients
- 1 shot [[Gold Strike|gold strike]]
- 1 shot [[Jägermeister|jägermeister]]
# Notes
- 1 serving
- Requirements: [[Tumbler]]
- Contains XX% ABV
# Directions
1. Combine the gold strike and jägermeister.
 #Source/Wikipedia #Course/Drink/Alcoholic #Course/Drink #Diet/Vegan  