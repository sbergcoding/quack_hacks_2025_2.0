# Ingredients
- 1/3 shot [[Sambuca|sambuca]]
- 2/3 shot [[Gold Strike|goldstrike]]
# Notes
- 1 serving
- Requirements: [[Shot Glass|shot glass]]
- Contains 46.04% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 