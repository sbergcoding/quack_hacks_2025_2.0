# Ingredients
- 1/2 shot [[Kontiki|kontiki]]
- 1/2 shot [[Vodka|vodka]]
- 1/2 shot [[Vodka Red|vodka red]]
- [[AA Sports Drink]]
# Notes
- 1 serving
- Requirements: [[Tumbler|tumbler]]
- Contains 5.3% ABV
# Directions
1. Mix the kontiki and vodka.
2. Top up with AA drink.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 