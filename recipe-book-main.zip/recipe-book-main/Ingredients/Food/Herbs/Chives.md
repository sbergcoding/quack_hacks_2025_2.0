*Chives* are a plant native to Europe, Asia, and North America. It is related to the [[Onion|onion]] family, most closely [[Scallions|scallions]]. As such, they boast an onion-like flavour, though it is noted to be much milder than an actual full-grown onion. Along with this, it has a fresh, grassy, herbal flavour to round it out.
It is best (and most commonly) used as a garnish, chopped and sprinkled on top of any dish that could do with a touch of onion. They can also be added last-minute when cooking, adding to the flavour.
The flowers of the plant can also be used, boasting an even milder flavour.
Due to the fragile nature of the plant, it is recommended to snip them with scissors rather than chopping them with a knife.

If substituting for chives, the green end of scallions can be used, though it is slightly stronger. [[Parsley|parsley]] can emulate the herbal notes, but again, should be used sparingly.

#Ingredient 