Red onions are, obviously, [[Onion|onions]] that are red. They add a spicy-to-mild kick to anything that they are added to, as well as being great for adding a splash of colour to a dish. They're well-suited for #TypeOfFood/Salad , #TypeOfFood/Salsa, or #TypeOfFood/Sandwich. 

#Ingredient 

[[TODO]]