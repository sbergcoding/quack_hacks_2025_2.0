# Ingredients
- 2 shots [[Hoppe Vieux|hoppe vieux]]
- 1 shot [[Cola|cola]]
# Notes
- 1 serving
- Requirements: [[Tumbler|tumbler]]
- Contains 23.33% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 
