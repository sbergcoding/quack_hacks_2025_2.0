# Ingredients
- 50 g [[Butter|unsalted butter]]
- 50 g [[Flour|flour]]
- 400 ml [[Milk|milk]]
- 1 tsp [[Nutmeg|nutmeg]]
- 400g [[Pasta|pasta]]
- 400g [[Leek|(cut) leek]]
- 200g [[Ham|ham]] 
- 175g [[Cheese|cheese of choice]]
# Notes
- 3 people
- Dishes: 1 pot, 1 pan
- Time: ± 30 minutes
# Directions
1. Melt the butter in a large pan and add the flour. Cook for 3 minutes until the mixture becomes a [[Roux|roux]]. Gradually add the milk, and bring to a boil. Cook (while stirring) until it has become a thick sauce. Add nutmeg, [[Black Pepper|pepper]] and salt to taste.
2. Cook the pasta al dente to package instructions. Add the leek for the last minute. 
3. Cut the ham into strips or cubes. 
4. Add the pasta, leek, ham, and cheese to the sauce, and mix. Heat the entire dish for another 2 minutes.

#Cuisine/American/USA #Course/Main #TypeOfFood/Pasta #Diet/Vegetarian #Diet/Meat/Pork 