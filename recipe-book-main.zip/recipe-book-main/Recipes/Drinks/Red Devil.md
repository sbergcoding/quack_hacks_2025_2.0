# Ingredients
- 1/2 shot [[Marasquin|marasquin]]
- 1/2 shot [[Stroh-80|stroh-80]]
- 1 shot [[Fanta|fanta]]
# Notes
- 1 serving
- Requirements: [[Tumbler|tumbler]]
- Contains 27.25% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 