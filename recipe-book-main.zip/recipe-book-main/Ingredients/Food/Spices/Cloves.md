*Cloves* are flower buds of a subtropical evergreen tree. It has a strong, distinct bittersweet taste. Because of how strongly it can flavour anything, very little is usually used in any recipe. 
It is highly recommended that, when using whole cloves, they're strained or otherwise removed from the dish.

The spice is great for flavouring #TypeOfFood/Sauce  or #TypeOfFood/Soup, and is often used in [[Rice|rice]] dishes, as well as Indian cooking.
Additionally, it is used in dessert and baked goods, as well as warm drinks.

#Ingredient 