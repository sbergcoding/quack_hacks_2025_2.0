# Ingredients
- 1/3 cup [[Mirin|mirin]]
- 3 tbsp [[Sake|sake]]
- 3 tbsp [[Light Soy Sauce|light soy sauce]]
- 2 tbsp [[Sugar|sugar]]
- 1 tsp [[Paprika|paprika]]
- 1 1/2 lbs [[White Fish|firm white fish]], such as [[Sea Bass|sea bass]], cut into 3-cm cubes.
- 2 tbsp [[Oil|neutral oil]]
- 300g [[Rice|rice]], freshly cooked
- *1 [[Scallions|scallion]]*
- *1 tbsp [[Sesame Seed|sesame seeds]], lightly toasted*
# Notes
- 3 servings
- Requirements: Skillet, grill, skewers
- Time: 
# Directions
1. In a medium skillet over medium heat, combine the mirin, sake, soy sauce, sugar, and paprika, and bring to a steamy simmer. Swirl the skillet to dissolve the sugar. Continue until tight, glossy, foamy bubbles cover most of the surface (~5 1/2 minutes). Remove from heat and cool for 5-6 minutes, to the consistency of a loose glaze.
2. Preheat the grill to medium-high.
3. Thread the cubed fish onto skewers. Drizzle with oil, and turn gently to coat.
4. Cook the fish skewers until cooked through and lightly charred (6-8 minutes). Just before removing from the grill, brush over with the glaze.
5. Serve with rice, and garnish with the scallion and sesame seeds.
#Cuisine/Asian #Source/DnD #Course/Main #TypeOfFood/Rice  #Diet/Pescatarian