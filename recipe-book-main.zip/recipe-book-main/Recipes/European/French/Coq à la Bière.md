# Ingredients
- 1.5 kg [[Chicken Leg|chicken legs]]
- 250g [[Chestnut Mushrooms|chestnut mushrooms]]
- 125g [[Bacon|bacon bits]]
- 5 [[Shallots|shallots]]
- 3 cloves [[Garlic|garlic]]
- 660ml [[Beer|triple distilled beer]]
- 2 [[Bay Leaves|bay leaves]]
- 1 [[Carrot|carrot]]
- 1 [[Stock Cube|chicken stock cube]]
- Fresh [[Thyme|thyme]]
# Notes
- 4 servings
- Requirements:
- Time: 30 min prep, 90 min waiting
# Directions
1. Sprinkle the chicken legs with [[Salt|salt]] and [[Black Pepper|pepper]]. Heat some [[Butter|butter]], and brown the chicken on medium high heat. Remove from the pan and set aside.
2. Remove excessive fat, and fry the bacon bits for a couple of minutes. Meanwhile, slice up the mushrooms and carrot, halve the shallots, and mince the garlic.
3. Add the mushrooms and carrot to the bacon. When these are browned, add the shallots and garlic, and mix.
4. Pour in the beer along with one crumbled chicken stock cube, the bay leaves, and a few sprigs of thyme. Bring to a boil, and add the chicken. Put on a lid, and let simmer on low medium heat for about 90 minutes.
5. Remove the chicken from the pan and set aside. Remove the thyme sprigs and the bay leaves. Let the remaining liquid simmer on high heat for about 10 minutes to thicken the sauce. Re-add the chicken and make sure the chicken is hot before serving.
#Cuisine/European/French #Source/Smaakmenutie #Course/Side #TypeOfFood/Chicken #Diet/Meat/Chicken 