# Ingredients
- 1 1/2 tbsp [[Oil|oil]]
- 1 medium [[Yellow Onion|yellow onion]], chopped
- 1 red [[Bell Pepper|bell pepper]], chopped
- 1 green [[Bell pepper|bell pepper]], chopped
- 1 [[Habanero|habanero pepper]]
- 1 tbsp [[Tomato Paste|tomato paste]]
- 2 tsp [[Thyme|thyme]], minced
- 1 tsp [[Garlic|garlic]], pressed/grated
- 4 [[Tomatoes|plum tomatoes]], chopped
- 10 oz [[Herring|smoked herring]]
- 6 [[Scallions|scallions]], thinly sliced
- 1 tbsp [[Lime Juice|lime juice]]
# Notes
- 4 servings
- Requirements:
- Time: 
# Directions
1. In a large skillet over medium heat, warm the oil until shimmering. Add the onion, bell peppers, habanero, and a pinch of [[Salt|salt]], and cook until softened for ±5 minutes. 
2. Add the tomato paste and cook until fragrant and a shade darker, ±1 1/2 minutes. Add the thyme and garlic and cook for another 40 seconds. Add the tomatoes, and cook until softened (±3 minutes). 
3. Add the herring and cook until heated through, for about 3 minutes. Incorporate the scallions and lime juice, and season with [[Black Pepper|black pepper]] to taste.
#Cuisine/Fusion #Source/DnD #Course/Side #TypeOfFood/Fish #Diet/Pescatarian  