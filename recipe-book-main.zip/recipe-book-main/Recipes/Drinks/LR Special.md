# Ingredients
- 1 shot [[Bacardi Blanca|bacardi blanca]]
- 1 shot [[Gin|gin]]
- 1/2 shot [[Crème de Cassis|crème de cassis]]
- 3 shots [[Orange Juice|orange juice]]
# Notes
- 1 serving
- Requirements: [[Tumbler]]
- Contains 15.18% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 
