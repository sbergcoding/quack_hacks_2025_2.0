# Ingredients
- 1/2 shot [[Blue Curaçao|blue curaçao]]
- 1/2 shot [[Sambuca|sambuca]]
- 1/2 shot [[Piña Colada|piña colada]]
- [[Sprite]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 4.5% ABV
# Directions
1. Mix the blue curaçao, sambuca, and piña colada.
2. Top up with sprite.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 