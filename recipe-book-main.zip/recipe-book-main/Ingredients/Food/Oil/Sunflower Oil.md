Generic-use oil, but best used in moderation.

- Good for stir-frying and sauteing

#Ingredient 

[[TODO]]