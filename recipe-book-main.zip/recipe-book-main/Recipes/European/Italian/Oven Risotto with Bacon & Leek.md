# Ingredients
- 200g [[Bacon|bacon bits]]
- 3 [[Leek|leeks]]
- 300g [[Rice|risotto rice]]
- 750ml [[Vegetable Stock|vegetable stock]]
- 225g [[Garden Peas|garden peas]]
- 125g [[Crème Fraîche|crème fraîche]]
# Notes
- 3 people
- Requirements: 1 oven dish, 1 pan
- Time: ~1 hour
# Directions
1. Preheat the oven to 180°C.
2. Fry the bacon bits in a pan for 5 minutes in an already-hot pan. Meanwhile, halve the leeks, wash them, and cut into half-rings. 
3. Add the leek to the bacon bits and fry for 5 minutes on low heat.
4. Add the rice, and cook for 2 minutes until the grains turn glassier.
5. Move the current mixture to an oven dish, and add all of the vegetable stock. Put in the oven for 35 minutes.
6. Add the garden peas and crème fraîche to the risotto, and put back in the oven for five more minutes. Add [[Black Pepper|pepper]] to taste.

#Cuisine/European/Italian #Course/Main #TypeOfFood/Risotto #Diet/Meat/Pork 