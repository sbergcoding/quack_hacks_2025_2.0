# Ingredients
- 1/3 shot [[Spiced Rum|spiced rum]]
- 1/3 shot [[Café Marrakesh|café marrakesh]]
- 1/3 shot [[Malibu Rum|malibu rum]]
# Notes
- 1 serving
- Requirements: [[Shot Glass|shot glass]]
- Contains 26.3% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 