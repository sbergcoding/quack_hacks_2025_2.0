# Ingredients
- 1 shot [[Baileys|baileys]]
- 1 shot [[Cointreau|cointreau]]
- 1 shot [[Tia Maria]]
- 1 shot [[Vodka]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 28.63% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 