# Ingredients
- 1 shot [[Vodka|vodka]]
- 1 shot [[Cointreau|cointreau]]
- 1 shot [[Baileys|baileys]]
- [[Chocolate Milk|chocolate milk]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 12.6% ABV
# Directions
1. Mix the vodka, cointreau, and baileys.
2. Top up with chocolate milk.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegetarian 