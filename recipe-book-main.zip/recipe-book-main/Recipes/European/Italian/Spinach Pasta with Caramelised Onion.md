# Ingredients
- 3 medium [[Yellow Onion|yellow onions]]
- 300g [[Pasta|pasta]]
- 450g [[Spinach à La Crème|spinach à la crème]]
- 175g [[Cheese|grated cheese]]
# Notes
- 3 people
- Requirements: 1 pot, 1 pan
- Time: ~20 minutes
# Directions
1. Cut the onions in half rings. Heat the oil on medium heat in a pan, and boil water for the pasta.
2. Caramelise the onion in 15 minutes and cook the pasta in the meantime.
3. Drain the pasta, and return to the pan. Add the spinach and most of the cheese. Stir until the cheese is melted. Add [[Salt|salt]] and [[Black Pepper|pepper]] to taste.
4. Mix in the caramellised onion, or use as garnish. Add the rest of the cheese on top of the servings, and serve hot.

#Cuisine/European/Italian #Course/Main #TypeOfFood/Pasta #Diet/Vegetarian