---
aliases:
  - wodka
  - Wodka
---
Vodka is a clear, colourless, strong liquor that is widely consumed in Russia, Poland and Finland. It is distilled from grains like wheat, rye, or [[Potato|potatoes]]. It is distilled to a maximum of 96% ABV, and then filtered over charcoal, and diluted with water. This is to absorb any impurities in the liquid.
Generally, vodka is odourless, as it consists of almost nothing other than ethanol and water.

It is the chief ingredient in [[Bloody Mary|bloody maries]], [[Blue Lagoon|blue lagoons]], [[Caipiroska|caipiroskas]], [[Cosmopolitan|cosmopolitans]], [[Gold Digger|gold diggers]], [[Moscow Mule|moscow mules]], [[Sea Breeze|sea breezes]], [[Flatliner|flatliners]], [[White Russian|whtie russians]], and [[Vodka Daisy|vodka daisies]], as well as [[Screwdriver|screwdrivers]] and [[Vodka Red|vodka reds]].

Commercially available vodka has an ABV of anywhere between 37.5% and 70%; but generally is somewhere between 40% and 45%.


#Ingredient 