# Ingredients
- 1 shot [[Bacardi Razz|bacardi razz]]
- [[Fanta|fanta]]
- Raket-ijsje
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 4.27% ABV
# Directions
1. Put the ice cream in the glass.
2. Add the bacardi razz.
3. Top up with fanta.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 