# Ingredients
- 1 shot [[Bacardi Razz|bacardi razz]]
- 1 shot [[Bacardi Black|bacardi black]]
- 1 shot [[Bacardi Lemon|bacardi lemon]]
- 1 shot [[Bacardi Blanca|bacardi blanca]]
- [[Cola]]
# Notes
- 1 serving 
- Requirements: [[Beer Mug|beer mug]]
- Contains 11.16% ABV
# Directions
1. Mix the different Bacardis.
2. Top up with cola.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 