*Avocado oil* is a type of [[Oil|oil]], pressed from fresh [[Avocado|avocado]] pulp. It is considered a 'healthier' oil, due to more monosaturated fats and other essential oils. It has a high smoke point, which makes it a viable option for high-heat cooking, such as sautéing, roasting, and searing. The smoke point sits at 375-400F. 
Unrefined avocado oil tastes strongly of avocado, but refined oil - or heated unrefined oil - makes it largely neutral.
When used in something like #TypeOfFood/Vinaigrette, unrefined avocado oil adds something of a herbaceous, nutty taste.

It does, however, have a relatively high price point.

#Ingredient 