# Ingredients
- 1/3 shot [[Monin Grenadine|monin grenadine]]
- 3 shots [[Tonic|tonic]]
- 1/3 shot [[Lemon Juice|lemon juice]]
- [[Sprite]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 0.00% ABV
# Directions
1. Mix the grenadine syrup, the tonic, and the lemon juice.
2. Top up with sprite.
#Course/Drink #Course/Drink/Non-Alcoholic #Source/DeBolk #Diet/Vegan 