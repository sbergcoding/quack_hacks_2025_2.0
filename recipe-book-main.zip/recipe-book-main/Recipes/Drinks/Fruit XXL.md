# Ingredients
- 1 shot [[Safari|safari]]
- 1 shot [[Kontiki|kontiki]]
- 1 shot [[Bacardi Lemon|bacardi lemon]]
- [[Apple Juice|Apple juice]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 10.13% ABV
# Directions
1. Mix the safari, kontiki, and bacardi lemon.
2. Top up with apple juice.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 