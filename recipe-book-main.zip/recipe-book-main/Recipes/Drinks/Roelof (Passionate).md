# Ingredients
- 2 shots [[Passoã|passoa]]
- 1 bottle of [[AA Sports Drink|aa sports drink]]
# Notes
- 1 serving
- Requirements: [[Beer Mug|beer mug]]
- Contains 2.91% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 