# Ingredients
- 1/2 shot [[Jameson]]
- 1/2 shot [[Tia Maria]]
- [[Bitter Lemon|bitter lemon]]
# Notes
- 1 serving
- Requirements: [[Tumbler|tumbler]]
- Contains 4.0% ABV
# Directions
1. Mix the Jameson and the Tia Maria.
2. Top up with bitter lemon soda.
3. Let sit for a bit to separate.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 