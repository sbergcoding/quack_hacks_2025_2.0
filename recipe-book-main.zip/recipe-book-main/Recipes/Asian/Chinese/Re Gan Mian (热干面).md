 # Ingredients
- 3 tbsp [[Tahini|sesame paste / tahini]]
- 3 1/2 tbsp [[Sesame Oil|sesame oil]]
- 1 1/2 tsp [[Dark Soy Sauce|dark soy sauce]]
- 1 tbsp [[Light Soy Sauce|light soy sauce]]
- 1/2 tsp [[Sugar|sugar]]
- 240g [[Noodles|alkaline noodles]]
- 2 cloves [[Garlic|garlic (minced)]]
- [[Chilli Oil|Chilli oil]] to taste
- 1/4 cup [[Cilantro|cilantro]]
- 2 chopped [[Scallions|scallions]]
- 1/2 tsp [[Chinese Black Vinegar|Chinese black vinegar]]
- *1/4 cup [[Preserved Mustard Stems (榨菜)|preserved mustard stems (榨菜)]]
- *1/4 cup [[Pickled Long Beans (酸豆角）|pickled long beans (酸豆角)]]
# Notes
- Serves two
- Time: 20 minutes
- 1 pan, 1 bowl

# Sauce
1. Add the sesame paste/tahini to a bowl. Gradually mix in 2 tbsp of sesame oil.
2. Add the soy sauces and the sugar. Mix until smooth.
> [!tip] 
> If the sauce is too thick, add lukewarm water until desired thickness is achieved.
# Directions
1. Boil noodles per package instructions minus one minute.
2. Drain and toss with the remaining oil to prevent sticking.
3. Add *zha cai*, *suan dou jiou*, garlic, chilli oil, cilantro, scallions, vinegar and the sauce.
4. Serve hot.
#Cuisine/Asian/Chinese #Course/Main #TypeOfFood/Noodles #Diet/Vegan  