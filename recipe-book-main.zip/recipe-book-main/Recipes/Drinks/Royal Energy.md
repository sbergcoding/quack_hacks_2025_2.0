# Ingredients
- 1 shot [[Gold Strike|gold strike]]
- 1 can [[Energy Drink|energy drink]]
# Notes
- 1 servings
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains XX% ABV
# Directions
1. Pour the shot of gold strike.
2. Top up with energy drink for as far as possible. Serve the rest of the energy drink separately.
 #Source/Wikipedia #Course/Drink/Alcoholic #Course/Drink #Diet/Vegan  