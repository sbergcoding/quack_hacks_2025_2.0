# Ingredients
- 1 shot [[Blue Curaçao|blue curaçao]]
- 1 shot [[Bacardi Blanca|bacardi blanca]]
- 1 shot [[Passoã|passoa]]
- [[Orange Juice|Orange juice]]
# Notes
- 1 serving
- Requirements: [[Tumbler|tumbler]]
- Contains 8.92% ABV
# Directions
1. Mix the blue curaçao, bacardi blanca and the passoa.
2. Top up with orange juice.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 