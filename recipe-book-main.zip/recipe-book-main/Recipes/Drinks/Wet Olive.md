# Ingredients
- 1 shot water
- 1 [[Olive|olive]]
# Notes
- 1 serving
- Requirements: [[Shot Glass|shot glass]]
- Contains 0.0% ABV
# Directions
1. Put the olive in a shot of water.
#Course/Drink #Course/Drink/Non-Alcoholic #Source/DeBolk #Diet/Vegan 