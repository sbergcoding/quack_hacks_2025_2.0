# Ingredients
- 1/2 shot [[Dropshot|dropshot]]
- 1/2 shot [[Sambuca|sambuca]]
# Notes
- 1 serving
- Requirements: [[Shot Glass|shot glass]]
- Contains 29.0% ABV
# Directions
1. Mix ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 