# Ingredients
- 1/2 shot [[Pisang Ambon|pisang ambon]]
- 1 shot [[Tia Maria|tia maria]]
- [[Ice Tea Green|Ice tea green]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 4.07% ABV
# Directions
1. Mix the pisang ambon and tia maria.
2. Top up with ice tea green.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 