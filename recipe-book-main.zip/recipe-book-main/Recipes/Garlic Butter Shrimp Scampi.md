# Ingredients
- 1/2 cup [[Unsalted Butter|unsalted butter]]
- 4 cloves [[Garlic|garlic]]
- 1 medium [[Shallots|shallots]]
- 1/4 tsp [[Crushed Red Pepper Flakes|crushed red pepper flakes]]
- 1 1/2 pounds medium [[Shrimp|shrimp]], peeled and deveined
- 3 tbsp [[Parsley|parsley]], chopped
- 1 tbsp [[Lemon|lemon juice]] 
- 2 tsp [[Lemon|lemon zest]]
# Notes
- 4 servings
- Requirements:
- Time: ±20 minutes 
# Directions
1. Melt butter in a large cast iron skillet over medium heat. Add the garlic, shallot and red pepper flakes. Cook until fragrant, stirring frequently.
2. Add shrimp; season with [[Salt|salt]] and [[Black Pepper|pepper]], to taste. Cook, stirring occasionally, until pink and cooked through (±4 minutes)
3. Stir in parsley, lemon juice, and lemon zest.
4. Serve immediately. 
#Cuisine #Source/DamnDelicious #Course/Main #TypeOfFood/Shrimp #Diet/Pescatarian  