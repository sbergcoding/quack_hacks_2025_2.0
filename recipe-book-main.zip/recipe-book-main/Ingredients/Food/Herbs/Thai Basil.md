*Thai Basil* is a variant of [[Sweet Basil|basil]] that is commonly used in Asian recipes.
The herb has a distinctive, pronounced anise-like flavour. It is more savoury than [[Sweet Basil|sweet basil]], and is noted to have a spicy licorice flavour.

#Ingredient 

[[TODO]]