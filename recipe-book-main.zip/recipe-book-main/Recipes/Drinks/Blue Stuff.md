# Ingredients 
- 1 shot [[Amaretto|amaretto]]
- 1 shot [[Blue Curaçao|blue curaçao]]
- [[Sprite|sprite]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 5.67% ABV
# Directions
1. Mix the amaretto and blue curaçao.
2. Top up with Sprite.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 