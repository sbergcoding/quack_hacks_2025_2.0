# Ingredients
- 14 oz [[Cocktail Sausages|cocktail sausages]]
- 12 oz [[Bacon|lean bacon]]
- 3/4 cup [[Brown Sugar|brown sugar]]
# Notes
- X servings
- Requirements: [[Oven|oven]], [[Baking Sheet|baking sheet]]
- Time: ±1 hour
# Directions
1. Preheat your oven to 325F, and line a baking sheet with aluminium foil. Using a pair of kitchen shears, cut the slab of bacon into thirds.
2. Wrap 1/3 of each slice of bacon around each sausage, secure with a toothpick, and place on the baking sheet. Repeat with the remaining sausages and bacon.
3. Sprinkle brown sugar over sausages and bake at 325 for ±45 minutes, or until the bacon has cooked and is starting to brown.
#Cuisine/American/USA  #Source/OurBestBites #Course/Appetizer #TypeOfFood/Sausage #Diet/Meat/Pork 