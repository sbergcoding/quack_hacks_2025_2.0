# Ingredients
- 1 shot [[Apfelkorn|apfelkorn]]
- 1 shot [[Crème de Bananes]]
- 1 shot [[Hail & Thunder|hail & thunder]]
- 1 shot [[Jenever|ketel1]]
- 1 shot [[Passoã|passoa]]
- 1 shot [[Amaretto|amaretto]]
- [[Sprite]]
# Notes
- 1 serving
- Requirements: [[Beer Mug|beer mug]]
- Contains 10.59% ABV
# Directions
1. Mix the apfelkorn, crème de bananes, hail & thunder, ketel1, passoa, and amaretto.
2. Top up with sprite.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 