Technically a byproduct of extracting sugarcane, molasses has a sweet, smoky flavour that lends itself well to cookies and barbecued meats.

#Ingredient 

[[TODO]]