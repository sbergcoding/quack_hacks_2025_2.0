# Ingredients
- 1 shot [[Bacardi Lemon|Bacardi lemon]]
- 1 shot [[Vodka|vodka]]
- 1 shot [[Apfelkorn|apfelkorn]]
- [[Sprite|sprite]]
# Notes
- 1 serving
- Requirements: [[Beer Mug|beer mug]]
- Contains 6.72% ABV
# Directions
1. Mix the bacardi lemon, vodka, and apfelkorn.
2. Top up with sprite.
#Course/Drink  #Course/Drink/Alcoholic  #Source/DeBolk  #Diet/Vegan 