# Ingredients
- 6 oz [[Tamarind Pulp|tamarind pulp]]
- 1/4 cup [[Dates|dates]], tightly packed, quartered and pitted
- 1/4 cup [[Sugar|granulated sugar]]
- 1/2 tsp [[Vanilla Extract|vanilla extract]]
- [[Salt]]
- 3 tbsp [[Sugar|large-crystal sugar]]
# Notes
- 18 servings (balls)
- Requirements: Food processor, shallow bowl/deep plate
- Time: 15 minutes
# Directions
1. Break the tamarind pulp into very small bits using your fingers.
2. Transfer to a food processor. Add the dates, granulated sugar, vanilla, and a pinch of salt, and process until the ingredients are very finely chopped. (±45 seconds).
3. Place the large-crystal sugar into a wide, shallow bowl. Roll 2-tsp portions of the tamarind mixture into 18 balls, gently pressing as you roll to help them cohere.
4. Roll the balls in the crystal sugar, pressing gently to help it adhere.
#Cuisine/African #Source/DnD #Course/Snack #Diet/Vegan 