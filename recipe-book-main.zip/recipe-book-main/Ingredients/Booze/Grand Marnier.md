- [ ] 
*Grand Marnier* is a liquor made of French [[Cognac|cognac]] in combination with Caribbean [[Orange|oranges]]. Its flavour is noted as complex and rounded, with a hint of orange. 
It is ripened in oaken casks, giving it its complex flavour. The flavour starts with orange, followed by hints of [[Vanilla|vanilla]] and [[Caramel|caramel]]. 

Suggested uses are as the main component of a cocktail, as a digestif, or by itself as a shot next to a cup of [[Coffee|coffee]].
Grand marnier contains an ABV of 40%.

#Ingredient 