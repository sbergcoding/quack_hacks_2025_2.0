# Ingredients
- 1/2 shot [[Pisang Ambon|pisang ambon]]
- [[Beer|beer]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 10.47% ABV
# Directions
1. Add the 1/2 shot pisang to the longdrink glass.
2. Top up with beer.
3. Add a banana candy for garnish.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 