Also a syrup, it's a popular sugar product used in desserts such as baklava. It's very applicable to many things. It's also not considered vegan by all vegans.

#Ingredient 

[[TODO]]