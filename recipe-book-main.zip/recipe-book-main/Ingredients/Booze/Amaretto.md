- [ ] 
*Amaretto* is an Italian liquor made of [[Almonds|almonds]] or [[Apricot|apricot  pits]]. It is noted to have a mildly bitter taste, lending it its name: Amaretto means ‘slightly bitter’ in Italian. 
Ways of serving amaretto include [[On the Rocks|on the rocks]], [[Cocktails|cocktails]] or mixed with other drinks, namely [[Coffee|coffee]]. 

Amaretto has an ABV of 28%.

#Ingredient 