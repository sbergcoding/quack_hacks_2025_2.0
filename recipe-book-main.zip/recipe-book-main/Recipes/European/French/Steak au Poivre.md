# Ingredients
- 4 tbsp [[Cognac|cognac]]
- 4 [[Fillet Steak|fillet steaks]]
- 4 tbsp [[Four Season Pepper|four season peppercorns]]
- 1 tbsp [[Oil|oil]]
- 50g [[Butter|butter]]
- 125ml [[Crème Fraîche|crème fraîche]]
# Notes
- 4 servings
- Requirements: Mortar & pestle
- Time: 
# Directions
1. Pour the cognac into a deep plate or bowl, along with the fillet steaks, and let marinate for 5 minutes.
2. In a mortar and pestle, crush the peppercorns. When this is done, season the steaks with the pepper.
3. In a skillet, heat the oil and half of the butter. When the foam is almost subsided, sear the steak on high heat for 1 minute per side. Lower the heat and sear for 1-2 minutes longer per side.
4. Take the meat out of the pan, and wrap in aluminium foil. Throw away the frying liquids.
5. Add the cognac to the pan. Add the crème fraîche, and warm up for a little bit. 
6. Turn the heat off, and mix in the remaining butter. 
#Cuisine/European/French #Source/Allerhande #Course/Main #TypeOfFood/Meat #Diet/Meat/Beef 