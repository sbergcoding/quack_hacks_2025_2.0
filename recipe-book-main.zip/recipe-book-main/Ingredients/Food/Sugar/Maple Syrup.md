Maple syrup has a fluid yet viscous texture and a caramel flavour. It's great as a drizzle over pancake, a glaze, or on roast vegetables.

#Ingredient 

[[TODO]]