---
aliases:
  - maitake
---

Also called _hen of the woods_, these [[Mushrooms|mushrooms]] are light brown and grow in feathery clusters at the base of trees. It is native to North America, Europe, and China. They have a slightly peppery flavour, and a meaty texture that both hold up well when cooked for longer. 
 It's earthy and robust, making it ideal for #TypeOfFood/Soup , #TypeOfFood/Stew  and #TypeOfFood/Stirfry 

Maitake mushrooms should be rinsed (not soaked) before use, to wash off any dirt.
When cooking with them, they can be pulled apart into 3" slices - no need for a knife. Due to their texture, they do not overcook easily - brown them a little and they taste great.

#Ingredient 