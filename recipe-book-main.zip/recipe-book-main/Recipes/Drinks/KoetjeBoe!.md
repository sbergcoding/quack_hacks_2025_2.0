# Ingredients
- 1/2 shot [[Malibu Rum|Malibu rum]]
- 1/2 shot [[Piña Colada|piña colada]]
- 1/2 shot [[Bacardi Blanca|bacardi blanca]]
- [[Chocolate Milk|Chocolate milk]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 4.9% ABV
# Directions
1. Mix the rum, piña colada, and bacardi blanca.
2. Top up with chocolate milk.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegetarian 