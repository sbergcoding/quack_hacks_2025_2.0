# Ingredients
- 1 shot [[Hail & Thunder|hail & thunder]]
- [[Ginger Ale|ginger ale]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]], [[Shot Glass|shot glass]]
- Contains 3.33% ABV
# Directions
1. Pour the hail & thunder into the shot glass.
2. Fill the longdrink glass with ginger ale, but not to the top.
3. Drop the shot glass into the longdrink glass.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 