
# Ingredients
- 1/2 shot [[Blue Curaçao|blue curaçao]]
- 1/2 shot [[Coebergh|coebergh]]
- 1/2 shot [[Gin|gin]]
- 1/2 shot [[Vodka|vodka]]
- [[Grape Soda]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 6.93% ABV
# Directions
1. Mix the blue curaçao, coebergh, gin, and vodka.
2. Top up with grape soda.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 