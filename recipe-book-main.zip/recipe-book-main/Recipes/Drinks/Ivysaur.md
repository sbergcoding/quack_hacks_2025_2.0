# Ingredients
- 1 shot [[Pisang Ambon|pisang ambon]]
- 1 shot [[Limoncello|limoncello]]
- [[Sprite]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains ?? ABV
# Directions
1. Mix the pisang ambon and limoncello.
2. Top up with Sprite.
#Course/Drink #Course/Drink/Alcoholic #Source/KarpeNoktem #Diet/Vegan 