# Ingredients
- X
# Notes
- X servings
- Requirements:
- Contains XX% ABV
# Directions
1.
 #Source [alcohol?] #Course #Diet 