# Ingredients
- 1 shot [[Tequila|tequila]]
- 1 shot [[Café Marrakesh|café marrakesh]]
- Ice
# Notes
- 1 serving
- Requirements: [[Tumbler|tumbler]] 
- Contains 30.5% ABV
# Directions
1. Mix the tequila and café Marrakesh in the tumbler.
2. Serve over ice.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 