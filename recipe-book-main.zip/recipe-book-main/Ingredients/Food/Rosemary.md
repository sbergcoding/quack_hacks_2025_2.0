*Rosemary* is an herb native to the Mediterranean regions. It comes from the [[ Mint|mint]] family of plants. It is known for its distinct woody stems with needle-like leaves, and its evergreen aroma.
The herb has notes of evergreen, citrus, lavender, pine, sage, pepper, mint, and sage 

[[TODO]]