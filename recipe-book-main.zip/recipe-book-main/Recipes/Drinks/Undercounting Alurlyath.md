# Ingredients
- 1 [[Cucumber|cucumber]], scrubbed but not peeled
- 60ml [[Dry Sherry|dry sherry]]
- 30ml [[Honey Syrup|honey syrup]]
> [!warning] Honey is not considered vegan by all vegans. 
- 1 tsp [[Lemon Juice|lemon juice]]
- 360ml [[Seltzer|seltzer]], cold
# Notes
- 2 servings
- Requirements: [[Longdrink Glass|longdrink glass]], [[Cocktail Shaker|cocktail shaker]]
- Contains XX% ABV
# Directions
1. Cut the cucumber in half crosswise, then cut two thin slices from the cut side oof one half and reserve them for garnish. Chop the rest of the cucumber halves and transfer to a food processor. Process into a liquid pulp.
2. Line a medium bowl with a clean kitchen towel. Scrape hte cucumber pulp into the centre, and wring out as much liquid as possible. Toss the pulp.
3. Fill a cocktail shaker with the sherry, honey syrup, and lemon juice. Shake to mix.
4. Add 1 cup of cucumber juice, and stir to combine.
5. Fill two wine glasses about halfway with ice, add half the mixture to each, and top each with 180ml of seltzer, and stir gently. Garnish with a cucumber slice before serving.
 #Source/DnD #Course/Drink/Alcoholic #Course/Drink #Diet/Vegetarian #Diet/Vegan  