# Ingredients
- 1/3 shot [[Pisang Ambon|pisang ambon]]
- 1/3 shot [[Tia Maria|tia maria]]
- 1/3 shot [[Jameson|jameson]]
- [[Bitter Lemon|Bitter lemon]]
# Notes
- 1 serving
- Requirements: [[Tumbler]]
- Contains 3.56% ABV
# Directions
1. Mix the pisang ambon, tia maria, and jameson.
2. Top up with bitter lemon.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 