*Absinthe* is a liquor on the basis of [[Anise|anise]], [[Fennel|fennel]], and some additional herbs. It generally has a green or green-yellow tint, but can also be bottled as a colourless distillate. 
It is sometimes drank pure, but traditionally, water and sugar are dripped in before consumption, through the use of a special [[Absinthe Spoon|absinthe spoon]]. In modern consumption, the sugar will also be flambéed.

Absinthe has a variable ABV, ranging from 40% to 80%.

#Ingredient 