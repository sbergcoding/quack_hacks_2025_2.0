*Blue Curaçao* is a liquor from Flinders and the Netherlands, made from the dried peels of the curaçao, a variant of [[Orange|oranges]]. It is primarily known for being blue, but it is also possible to obtain the liquor in other colours. Generally, it is used as a mixer or cocktail, as a sort of alcoholic food colouring; by itself it tastes extremely sweet. The colouring is very persistent.

Blue curaçao contains an ABV of 20%.

#Ingredient 