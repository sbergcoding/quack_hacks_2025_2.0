# Ingredients
- 1 shot [[Gold Strike|gold strike]]
- 1 shot [[Blue Curaçao|blue curaçao]]
# Notes
- 1 servings
- Requirements: [[Tumbler|tumbler]]]]
- Contains XX% ABV
# Directions
1. Combine the gold strike and the blue curaçao.
 #Source/Wikipedia #Course/Drink/Alcoholic #Course/Drink #Diet/Vegan 