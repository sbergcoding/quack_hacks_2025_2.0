---
aliases:
  - tabouli
---
# Ingredients
- 1/2 cup [[Bulgur|bulgur]]
- 1 cup [[Cucumber|cucumber]], diced
- 1 cup [[Tomato|tomatoes]], diced
- 1 tsp [[Salt|salt]]
- 3 bunches [[Parsley|curly parsley]]
- 1/3 cup [[Mint|mint]]
- 1/3 cup [[Scallions|scallion]]
- 1/3 cup [[Olive Oil|olive oil]]
- 3 to 4 tbsp [[Lemon Juice|lemon juice]]
- 2 cloves [[Garlic|garlic]]
# Notes
- 6 servings
- Requirements: 
- Time: 45 minutes
> Tabbouleh keeps well in the refrigerator for up to 4 days.
# Directions
1. Cook or soak the bulgur until tender, according to package directions. Drain excess water.
2. Combine the diced cucumber and tomato in a medium bowl, along with 1/2 tsp of the salt. Stir and let rest for at least 10 minutes.
3. Cut the thick stems off the parsley. Finely chop the leaves and remaining stems.
4. Add the cooled bulgur, chopped fresh mint, and green onion to the parsley. Strain off.
5. In a small measuring cup or bowl, whisk together the olive oil, the lemon juice, the garlic, and the remaining salt. 
6. If possible, let the salad rest for 15 minutes before serving.
#Cuisine/African/Lebanese #Source/CookieAndKate #Course/Side #TypeOfFood/Salad #Diet/Vegan 