# Ingredients
- 1/2 shot [[Sambuca|sambuca]]
- 1/2 shot [[Tequila|tequila]]
- [[Tabasco|tabasco]]
# Notes
- 1 serving
- Requirements: [[Shot Glass|shot glass]]
- Contains 38.0% ABV
# Directions
1. Mix the sambuca and tequila.
2. Add a couple of drops of tabasco.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 