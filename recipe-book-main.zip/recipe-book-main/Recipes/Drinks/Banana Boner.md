# Ingredients
- 1 shot [[Blueberry Liqueur|blueberry liqueur]]
- 1 shot [[Passoã|passoa]]
- [[Banana Juice|banana juice]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 4.25% ABV
# Directions
1. Mix the blueberry liqueur and passoa.
2. Top up with banana juice.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 