# Ingredients
- 12 large [[Button Mushrooms|button mushrooms]]
- 2 [[Shallots|shallots]]
- 1 clove [[Garlic|garlic]]
- 4 tbsp [[Olive Oil|olive oil]]
- 
- 250g [[Cheese|ricotta cheese]]
- 7.5g [[Parsley|parsley]]
- 12.5g [[Chives|chives]]
- 1 [[Lemon|lemon]]
- 5 tbsp [[Bread Crumbs|bread crumbs]]
# Notes
- 3 people
- Requirements: 1 pan, 1 bowl, oven
- Time: ~30 minutes
# Directions
1. Remove the stems from the mushrooms, and finely cut the stems along with the shallots and garlic.
2. Heat half of the olive oil in a pan on medium high heat. Fruit the shallots for 4 minutes. Add the garlic, and fry for another 3 minutes. When the shallots are glassier, add the mushroom stems and fry for 3 minutes. Remove the pan from heat.
3. Stir the ricotta loose in a bowl, and finely cut the parsley and the chives. Add 3/4 of the herbs to the ricotta and mix finely.
4. Zest and juice the lemon, and add to the ricotta mixture, along with the shallot mixture.
5. Preheat the oven to 200°C. 
6. Fill the mushroom caps with the ricotta-shallot mixture and put them on a parchment-lined baking tray. Sprinkle with bread crumbs, and bake in the oven for 15 minutes.
7. Garnish with the remaining herbs.

#Cuisine/European  #Course/Side #TypeOfFood/Mushrooms #Diet/Vegetarian