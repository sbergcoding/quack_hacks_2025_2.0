# Ingredients
- 400g [[Chicken Breast|chicken breast]]
- 250g [[Button Mushrooms|button mushrooms]]
- 50g [[Flour|flour]]
- 150ml [[Marsala Wine|marsala wine]]
- 3 cloves [[Garlic|garlic]]
- 1 [[Shallots|shallot]]
- 250ml [[Chicken Broth|chicken broth]]
- 2 tbsp [[Corn Starch|corn starch]]
- *[[Parsley]]*
# Notes
- 2 servings
- Requirements: Frying pan
- Time: 
# Directions
1. Halve the chicken breasts and flatten, so that you have 4-6 thin pieces of chicken. Sprinkle with [[Salt|salt]] and [[Black Pepper|black pepper]], and dust with the flour.
2. Heat some [[Oil|oil]] or [[Butter|butter]] in a frying pan, and fry the chicken until it is browned and fried through. Remove from the pan and set aside.
3. Dice the shallots and garlic, and slice the mushrooms.
4. In the chicken's frying liquid, fry the mushrooms. After some minutes, add the shallots.
5. Pour the marsala wine over the mixture and let reduce until approximately half the wine remains.
6. Add the chicken broth, and bring to a boil. Simmer for 5-10 minutes.
7. Add the corn starch to thicken the sauce, *and garnish with parsley.*
#Cuisine/European/Italian #Source/Smaakmenutie #Course/Side #TypeOfFood/Chicken #Diet/Meat/Chicken  