# Ingredients
- 1/2 shot [[Passoã|passoa]]
- 1/2 shot [[Bacardi Razz|bacardi razz]]
- [[Sprite]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 3.13% ABV
# Directions
1. Mix the passoa and bacardi razz.
2. Top up with Sprite
#Course/Drink  #Course/Drink/Alcoholic  #Source/DeBolk  #Diet/Vegan 