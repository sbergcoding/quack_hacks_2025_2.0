# Ingredients
- 1 shot [[Beerenburg|beerenburg]]
- [[Ice Tea|Ice tea]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 4.67% ABV
# Directions
1. Add the Beerenburg to the glass, and top up with ice tea.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 