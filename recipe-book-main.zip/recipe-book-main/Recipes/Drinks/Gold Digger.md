# Ingredients
- 1 shot [[Gold Strike|gold strike]]
- 1 shot [[Vodka|vodka]]
# Notes
- 1 servings
- Requirements: [[Tumbler]]
- Contains XX% ABV
# Directions
1. Mix the gold strike and the vodka.
 #Source/Wikipedia #Course/Drink/Alcoholic #Course/Drink #Diet/Vegan  