*Shiitake mushrooms* are a [[Mushrooms|mushroom]]  native to Eastern Asia, and cultivated around the globe. They grow on the decaying wood of deciduous tree, in mostly warm and moist climates. They are slender and light brown, with a tough, inedible stem. Shiitakes have a rich, meaty, almost buttery taste when cooked. 

To prepare the shiitake mushroom, they first should be cleaned. This can be done through the use of either a brush or a quick rinse, followed by a pat with a paper towel. After this, the stems should be removed. While technically edible, they are very tough and fibrous - they can likely be used for something like [[Stock|stock]], but it is probably better to just discard them. 
The caps aren't very thick, so they heat through very quickly. This makes them ideal for #TypeOfFood/Stirfry, #TypeOfFood/Noodles, or anything else that needs a quick boost in flavour. By themselves, they're also great when sautéed with some seasonings.

#Ingredient 