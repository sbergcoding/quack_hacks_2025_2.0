# Ingredients
- 350g [[Chicken Thigh Fillet]]
- 30g [[Cashew|cashews]]
- 2 cloves [[Garlic|garlic]]
- 2 [[Bell Pepper|bell peppers]], *of two different colours*
- 1 bushel [[Scallions|scallions]]
- 1 tbsp [[Hoisin Sauce|hoisin sauce]]
- 1 tbsp [[Oyster Sauce|oyster sauce]]
- 1 tsp [[Sambal|sambal]]
- 200g [[Rice|rice]]
# Notes
- 2 servings
- Requirements:
- Time: 25 minutes
# Directions
1. Cut the chicken thighs into bite-sized pieces, and mix in a heaping tablespoon of oyster sauce. Set aside.
2. Cut the bell peppers into cubes, and the scallions into rings.
3. Fry the chicken in a wok on medium high heat (preferably with some [[Oil|oil]]) until brown and crispy.
> [!warning] As counterintuitive as it is, don't wok the chicken just yet. Stirring it too much prevents it from becoming nice and crispy, we're just saving dishes here.
4. Add the bell peppers and 3/4 of the spring onion. Let sit as well, same as the chicken. After 4 minutes, stir to mix.
5. Add the hoisin sauce and the sambal. Stir to mix.
6. Serve on a plate of white rice, garnish with the remaining spring onions and cashews.
#Cuisine/Asian #Source/Smaakmenutie #Course/Main #TypeOfFood/Rice #Diet/Meat/Chicken  