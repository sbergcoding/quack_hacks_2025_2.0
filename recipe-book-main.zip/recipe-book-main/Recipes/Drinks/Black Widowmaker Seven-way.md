# Ingredients
- 1 shot [[Bacardi Blanca|bacardi blanca]]
- 1 shot [[Vodka|vodka]]
- 1 shot [[Blue Curaçao|blue curaçao]]
- 1 shot [[Coebergh|coebergh]]
- 1 shot [[Jameson|Jameson]]
- 1 shot [[Gin|gin]]
- 1 shot [[Grape Soda|grape soda]]
# Notes
- 1 serving
- Requirements: [[Beer Mug|beer mug]]
- Contains 25.93% ABV
# Directions
1. Mix ingredients, save for the grape soda.
2. Shake thoroughly.
3. Add the grape soda.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 