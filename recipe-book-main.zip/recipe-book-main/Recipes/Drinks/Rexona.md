# Ingredients
- 1 shot [[Blue Curaçao|blue curaçao]]
- 1 shot [[Hail & Thunder|hail & thunder]]
- 1 shot [[Piña Colada|piña colada]]
# Notes
- 1 serving
- Requirements: [[Tumbler|tumbler]]
- Contains 18.17% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 