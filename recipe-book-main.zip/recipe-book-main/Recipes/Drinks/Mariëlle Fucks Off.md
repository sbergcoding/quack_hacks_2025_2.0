# Ingredients
- 1/2 shot [[Blue Curaçao|blue curaçao]]
- 1/2 shot [[Bacardi Lemon|bacardi lemon]]
- 1 shot [[Hail & Thunder|hail & thunder]]
# Notes
- 1 serving
- Requirements: [[Tumbler|tumbler]]
- Contains 24.13% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 