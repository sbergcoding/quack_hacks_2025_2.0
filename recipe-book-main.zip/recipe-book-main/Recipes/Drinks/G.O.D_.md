# Ingredients
- [[Ginger Ale|ginger ale]]
- 1 shot [[Orange Bitters|orange bitters]]
- 1 shot [[Amaretto|disaronno]]
# Notes
- 1 serving 
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 7.73% ABV
# Directions
1. Mix the orange bitters and amaretto.
2. Top up with ginger ale.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 