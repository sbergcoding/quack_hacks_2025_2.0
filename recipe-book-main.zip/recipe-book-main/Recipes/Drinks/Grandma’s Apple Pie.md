# Ingredients
- 1 1/2 shots [[Apfelkorn|apfelkorn]]
- 1/2 shot [[Gold Strike|goldstrike]]
- [[Raisins|raisins]]
# Notes
- 1 serving
- Requirements: [[Tumbler]]
- Contains 23.38% ABV
# Directions
1. Mix the apfelkorn and goldstrike.
2. Add a couple of raisins as garnish.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 