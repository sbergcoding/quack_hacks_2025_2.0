# Ingredients
- 250g [[Pasta|pasta]]
- 300g [[Guanciale|guanciale]] / [[Bacon|bacon bits]]
> [!note] Preferably guanciale
- *150g [[Garden Peas|garden peas]]*
- ~100g [[Cheese|grana padano]]
- 2 eggs
- *250g [[Button Mushrooms|button mushrooms]]*

# Notes
- 3 people
- Requirements: 2 pans, cutting board, bowl
- Time: 30 minutes

#  Directions
## Sauce
1. Add most of the cheese and all of the eggs to a bowl. Add salt and [[Black Pepper|pepper]] to taste.
2. Mix thoroughly until smooth.
---
## Dish
1. Add the bacon bits to a hot pan. Fry for a couple of minutes, then remove and set aside.
2. *Fry the mushrooms in the leftover bacon grease*.
3. Cook the pasta according to package instructions. *Add the peas ~3 minutes before the pasta is done.*
4. Drain and add the pasta *and peas* to the bacon pan. Re-add the bacon and mix all of the above with the sauce *and the mushrooms*.
5. Serve hot and garnish with the remaining cheese.

#Cuisine/European/Italian #Course/Main #TypeOfFood/Pasta #Diet/Meat/Pork