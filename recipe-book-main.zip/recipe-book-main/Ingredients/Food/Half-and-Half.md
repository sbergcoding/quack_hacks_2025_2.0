*Half-and-half* is a mixture of half whole milk and half cream. It is richer than milk, but not quite as full as cream.
Generally, it is used to make a sauce, soup or dessert more creamy. The texture is thicker and more luscious than milk, but less decadent and rich than cream. 

When used, the mixture should be tempered first, as it will break and curdle due to rapid temperature changes otherwise. To do this, some of the hot liquid from the pan should be poured into a bowl, then the half-and-half should be added to this bowl. The warm half-and-half mixture can now be poured into the pan. 

#Ingredient