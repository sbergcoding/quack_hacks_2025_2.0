# Ingredients
- 60ml [[Whiskey|Scotch]]
- 22.5ml [[Lemon Juice|lemon juice]]
- 22.5 [[Honey & Ginger Syrup|honey & ginger syrup]]
> [!warning] Honey is not considered as vegan by all vegans.
- 7.5ml [[Whiskey|single malt Scotch whiskey]]
# Notes
- 1 servings
- Requirements: [[Tumbler|tumbler]], [[Cocktail Shaker|cocktail shaker]]
- Contains XX% ABV
# Directions
1. Shake the cheaper scotch, lemon juice, and honey & ginger syrup over ice.
2. Strain into ice-filled glass.
3. Top with the single malt Scotch.
#Course/Drink/Alcoholic #Course/Drink #Diet/Vegetarian #Diet/Vegan  