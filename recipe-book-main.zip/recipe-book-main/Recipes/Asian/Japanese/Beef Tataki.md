# Ingredients
- 1 tbsp [[Sunflower Oil|sunflower oil]]
- 300g [[Fillet Steak|fillet steak]]
- [[Sesame Seed|sesame seed]]
- 1 tbsp [[Light Soy Sauce|light soy sauce]]
- 2 tbsp [[Rice Vinegar|rice vinegar]]
- 1 tsp [[Sesame Oil|sesame oil]]
- 1 tsp [[Chilli Oil|chilli oil]]
- 1/2 tsp [[Ginger|ginger]]
- *2 cloves [[Garlic|garlic]], sliced*
- *1 [[Scallions|scallion]], sliced thinly*
# Notes
- 2 servings
- Requirements: freezer bag
- Time: 1 hour
# Directions
1. Let the meat come to room temperature, pat dry, and season with [[Salt|salt]], [[Black Pepper|black pepper]], and the sesame seeds. Heat the sunflower oil in a frying pan, and sear the meat for one minute on both sides on high heat. The outside should be seared brown.
2. Put the meat in a freezer bag, and put into the freezer for about 30 minutes.
3. Meanwhile, mix the soy sauce, rice vinegar, sesame oil, chilli oil and ginger in a bowl. 
4. Heat some more sunflower oil, and add the garlic slices to this. Fry for 2-3 minutes until the garlic is crispy and a golden brown. Pat dry, or let the oil drain on a paper towel.
5. Cut the meat into strips, as thin as possible. Serve with the sauce, *and garnish with the spring onion and garlic.*
#Cuisine/Asian/Japanese #Source/ClaudNine #Course/Side #TypeOfFood/Snack #Diet/Meat/Beef  