# Ingredients
- 160 g [[Pancetta|pancetta]] / *leave out if making vegetarian*
- 25 g [[Butter|unsalted butter]]
- 800 g [[Chestnut Mushrooms|chestnut mushrooms]]
- 1 1/2 [[Mushroom Stock|mushroom stock tablet]]
- 2 tbsp [[Dried Mushrooms|Euroma dried mushrooms]]
- 700 ml boiling water
- 250 g [[Rice|risotto rice]]
- 200 g [[Crème Fraîche|crème fraîche]]
- 75 g [[Parsley|fresh parsley]]
- 50 g [[Cheese|parmigiano reggiano]]
# Notes
- 3 people
- Requirements: 1 pot, 1 pan, 1 oven dish
- Time: 
# Directions
1. Heat the butter and fry the pancetta for 3 minutes. While frying the pancetta, quarter the mushrooms. Add the mushrooms to the pancetta and fry for 5 more minutes on high heat.
2. Add the stock and dried mushrooms, together with the boiling water, to a bowl and let the stock cubes dissolve.
3. Add the risotto rice to the pancetta and fry for 3 minutes on low heat until the grains are glassy.
4. Mix the stock/mushroom mixture and the pancetta mixture in the oven dish, and put in the oven on 180°C for 40 minutes. After 35 minutes, take out of the oven and add the crème fraîche, and put back in the oven for 5 minutes.
5. Finely slice the parsley. Take the risotto out of the oven, and mix in the cheese and 3/4 of the parsley.
6. Garnish with the remaining parsley, and serve hot.

#Cuisine/European/Italian #Course/Main #TypeOfFood/Risotto #Diet/Meat/Pork 