These [[Mushrooms|mushrooms]] are a vibrant yellow, with a complex, unique aroma. They boast peppery, nutty tones with a fruity hint, adding a pop of flavour to both savoury and sweet dishes. On their own, they can be sautéed in butter for a tasty #Course/Side  dish, or added to complex meat dishes. It works well as a #Course/Garnish, #TypeOfFood/Sauce ,or #TypeOfFood/Risotto .

Care should be taken not to overcook chanterelles. They are ready to heat as soon as they are heated through - not necessarily when they are browned. To brown them properly, a pan with sufficient heat spreading should be used.
Overcooked chanterelles are often not charred, but rather oily, chewy and generally not very enjoyable.
To avoid this, the mushrooms should be pat dry with a paper towel first, and they should be added last minute. 

To brown the chanterelles, high heat should be used. Flash frying them works well. When cut up, take note that the surface area of the mushroom is larger, and that it therefore will fry for longer and heat up quicker - leading it to overcook quicker.

#Ingredient 

