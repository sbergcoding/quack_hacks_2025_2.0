# Ingredients
- 8 slices [[Rye Bread|rye bread]]
- 1/2 cup [[Thousand Island Dressing|thousand island dressing]]
- 8 slices [[Swiss Cheese|swiss cheese]]
- 8 slices [[Corned Beef|corned beef]]
- 1 cup [[Sauerkraut|sauerkraut]]
- 2 tbsp [[Unsalted Butter|unsalted butter]], softened
# Notes
- 4 servings
- Requirements:
- Time: ±20 minutes
# Directions
1. Spread one side of the bread slices evenly with thousand island dressing.
2. On four of the slices, layer swiss cheese, 2 slices corned beef, sauerkraut, and swiss cheese. Top with the remaining bread slices, dressing-side down. Butter the top of each sandwich.
3. Place the sandwiches butter-side down on a griddle. Butter the top of each sandwich with the remaining butter. Grill until both sides are golden brown.
#Cuisine/American/USA #Source/AllRecipes  #Course/Lunch #TypeOfFood/Sandwich #Diet/Meat/Beef  