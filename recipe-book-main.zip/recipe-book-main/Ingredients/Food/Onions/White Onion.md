*White onions* have a papery white skin, and are milder and sweeter than yellow onions. They're good for serving raw, in sauces or salads.

#Ingredient 

[[TODO]]