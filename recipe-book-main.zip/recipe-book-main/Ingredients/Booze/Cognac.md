*Cognac* is a French liquor made by distilling [[White Wine|white wine]]. It is a region-bound name, with specific races of grape associated with it. 
Generally speaking, Ugni Blanc is used. After the harvest, these grapes are pressed to a sour, cloudy wine. After this, it is twice distilled in a copper kettle. After the first distillation, it is a sort of [[Brandy|brandy]] that does not meet the ABV requirements of cognac.
After distillation, it is ripened in oaken vats from the Limousin or Tronçais region. It is aged for two years. After this, it is generally diluted with demineralise water. 

Age of the bottle is determined by the time the cognac spent in a vat. After it is bottled, it no longer ages.

Aged cognac has a soft, rounded taste, moreso the older it is. 

#Ingredient 