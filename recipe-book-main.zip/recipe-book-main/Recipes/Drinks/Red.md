# Ingredients
- 1 shot [[Passoã|passoa]]
- 1 shot [[Gin|gin]]
- 1/2 shot [[Coebergh|coebergh]]
- [[Fanta|fanta]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 7.95% ABV
# Directions
1. Mix the passoa, gin, and coebergh.
2. Top up with Fanta.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 