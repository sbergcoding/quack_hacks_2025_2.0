# Ingredients
- 350g [[Sugar|granulated sugar]]
- 250ml water
- 9 [[Lemon|lemons]]
- 1700ml **cold** water
- ice as needed
# Notes
- 10 servings
- Requirements: Saucepan
- Time: 15 minutes
# Directions
1. Combine the 350g sugar and 250ml water in a saucepan. Stir to dissolve sugar while the mixture comes to a boil. Set aside, cool slightly.
2. Cut the lemons in half crosswise, and squeeze into a measuring cup. Add the pulp, but remove the seeds. Continue juicing until you have 375ml fresh juice/pulp.
3. Pour 1700ml of ice cold water into a pitcher. Stir in the lemon juice and pulp, and add simple syrup to taste. To cool, add ice.
#Course/Drink #Diet/Vegan #Course/Drink/Non-Alcoholic 