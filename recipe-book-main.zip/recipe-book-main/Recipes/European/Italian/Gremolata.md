# Ingredients
- 40g [[Parsley|parsley]]
- 1 [[Lemon|lemon]]'s worth of zest
- 1/2 lemon's worth of juice
- 1 clove [[Garlic|garlic]]
- 3 1/2 tbsp [[Olive Oil|olive oil]]
- [[Salt|Sea salt]] to taste
# Notes
- X servings
- Requirements:
- Time: 10 minutes
# Directions
1. Remove the thick stems from the parsley. Roughly chop the remaining stems and leaves.
2. In a bowl, mix the parsley, lemon zest and juice, the olive oil, and salt to taste.
3. Mix thoroughly.
#Cuisine/European/Italian #Source/FrancescaKookt #Course/Sauce #TypeOfFood/Sauce #Diet/Vegan  