# Ingredients
- 4 [[Chicken Breast|large chicken breasts]]
- 2 tbsp [[Cajun Seasoning|cajun seasoning]]
- 1 cup [[Broccoli|chopped broccoli]]
- 1/2 cup [[Cheddar Cheese|cheddar cheese]]
- 3 tbsp [[Cream Cheese|cream cheese]]
# Notes
- 4 servings
- Requirements: oven, cutting board
- Time: 40 minutes
# Directions
1. Preheat the oven to 375 degrees F.
2. Butterfly the chicken breasts.
3. Use salt and cajun seasoning on both sides of the chicken.
4. Combine the broccoli, cheddar, and cream cheese in a mixing bowl.
5. Stuff each chicken breast with the filling. Sprinkle more cajun seasoning on top.
6. Brush with oil on top, and bake for 25-30 minutes (or until the chicken is cooked through).
7. Serve hot.
#Cuisine/American/USA #Source/ItIsAKeeper #Course/Main #TypeOfFood/Chicken #Diet/Meat/Chicken  