deze is lekker
# Ingredients
- 1 shot [[Grand Marnier|grand marnier]]
- 2/3 shot [[Baileys|baileys]]
- 1/3 shot [[Amaretto|amaretto]]
# Notes
- 1 serving
- Requirements: [[Tumbler|tumbler]]
- Contains 30.32% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegetarian 