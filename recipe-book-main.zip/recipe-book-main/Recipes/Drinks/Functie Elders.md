# Ingredients
- 1 shot [[Frangelico|frangelico]]
- 1 shot [[Vodka|vodka]]
- [[Cola|cola]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 7.67% ABV
# Directions
1. Mix the frangelico and the vodka.
2. Top up with cola.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan