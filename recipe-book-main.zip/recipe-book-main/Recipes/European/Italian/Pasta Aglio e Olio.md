# Ingredients
- 500g [[Pasta|pasta]]
- 6 cloves [[Garlic|garlic]], thinly sliced
- 120ml [[Olive Oil|olive oil]]
- 1 tsp [[Chilli Flakes|chilli flakes]]
- 3 sprigs [[Parsley|parsley]], finely chopped
- [[Cheese|parmesan]] to taste
# Notes
- X servings
- Requirements:
- Time: 
# Directions
1. Bring a large saucepan of water to a boil with salt. Cook the spaghetti al dente, stirring occasionally.
2.  Put the garlic in a cold pan with the olive oil. Turn on medium high heat, and lower it to medium once the oil starts to bubble. Fry until the garlic is a golden brown, and remove from heat.
3. Drain the pasta.
4. Stir the chilli flakes through the pasta.
5. Mix the olive oil and garlic mixture into the pasta.
#Cuisine #Source #Course #TypeOfFood #Diet 