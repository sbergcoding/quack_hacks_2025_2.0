# Ingredients
- 1 tbsp corn starch
- 2 tbsp water
# Notes
- 1 serving (not recommended)
- Requirements: bowl
- Time: 30 seconds
# Directions
1. Mix one part corn starch with one to two parts water.
2. Put in the food asap. Direct consumption not recommended.
#Cuisine/Asian #Course/Ingredient #Diet/Vegan 