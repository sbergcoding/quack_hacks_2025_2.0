Leeks are like overgrown [[Scallions|scallions]], and are great in soups and sauces. Baking the leeks mellows their flavour and softens them. They can also function as greens by themselves, for example, [[Leek à la Gratinée|leek à la gratinée]]. 

#Ingredient 

[[TODO]]