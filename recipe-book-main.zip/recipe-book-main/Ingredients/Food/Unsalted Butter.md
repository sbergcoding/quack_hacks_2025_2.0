*Unsalted butter* is a form of [[Butter|butter]] that is principally used in cooking and baking. When no other butter is specified, this is likely what is used. It is used as a fat addition, as a tasty alternative to most [[Oil|oils]]. It has a relatively low smoke point, and chars off easily if used in excess.

#Ingredient 