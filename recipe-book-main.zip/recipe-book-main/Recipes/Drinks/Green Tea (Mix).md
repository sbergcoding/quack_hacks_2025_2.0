# Ingredients
- 1 shot [[Pisang Ambon|pisang ambon]]
- [[Ice Tea|Ice tea]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass]]
- Contains 2.8% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 