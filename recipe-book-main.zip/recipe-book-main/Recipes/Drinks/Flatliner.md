# Ingredients
- 1/2 shot [[Sambuca|sambuca]]
- 1/4 shot [[Tabasco|tabasco]]
- 1/2 shot [[Gold Strike|gold strike]]
# Notes
- 1 servings
- Requirements: [[Tumbler|tumbler]]
- Contains XX% ABV
# Directions
1. Pour the sambuca.
2. Using the back of a stirring spoon, add the tabasco.
3. Using the back of a stirring spoon, add the gold strike.
 #Source/Wikipedia #Course/Drink/Alcoholic #Course/Drink #Diet/Vegan  