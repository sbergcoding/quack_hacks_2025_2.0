# Ingredients
- 4 tbsp [[Butter|butter]]
- 1 bunch [[Chives|chives]]
# Notes
- 2-3 people
- Requirements: Microwave
- Time: 5 minutes
# Directions
1. Dice the chives.
2. Melt the butter in the microwave.
3. Add the diced chives to the butter, and stir in. 
4. *[[Salt|salt]] to taste.*

#Cuisine/European #Course/Garnish #Diet/Vegetarian 