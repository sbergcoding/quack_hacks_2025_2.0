*Simple syrup* is essentially just sugar water, but is an integral part of most [[Cocktails|cocktails]] or [[Mixed Drinks|mixed drinks]]. 

It is generally a 1:1 ratio of [[Granulated Sugar|granulated sugar]] to water. Sometimes a richer syrup is required; in which case, less water is usually used.

# Ingredients
- 1 tbsp [[Granulated Sugar|granulated sugar]]
- 1 tbsp water
# Notes
- 1 servings
- Requirements:
- Time: 
# Directions
1. Boil the sugar in water until dissolved. 
2. Let cool, and use.
  #Course/Ingredient #Course/Drink/Non-Alcoholic #Diet/Vegan  

