*Clarified butter* is solely the fat content of [[Butter|butter]]. All of the solids remaining from [[Milk|milk]], as well as any remaining water content, has been removed. Because of this, it can withstand higher temperatures than most butter, charring/browning at around 400-450F. 
Furthermore, it contains less calories, and it can be more easy to digest for people with lactose intolerance.

Clarified butter can be made from [[Unsalted Butter|unsalted butter]].
To do this, the butter should be melted, allowing the components to separate by density. The water will evaporate, and the remaining milk solids will sink to the bottom. When this is strained,  you will have clarified butter.

#Ingredient
