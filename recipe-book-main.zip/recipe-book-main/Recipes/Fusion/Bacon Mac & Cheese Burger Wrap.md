# Ingredients
- 1 lb [[Minced Meat|minced meat]]
- 1/2 cup [[Bacon|bacon]]
- 2 cups [[Macaroni|macaroni]]
- 1 cup [[Cheese|cheddar cheese]]
- 4 [[Tortilla|tortillas]]
- *[[Lettuce|lettuce]]* 
# Notes
- 4 servings
- Requirements: skillet
- Time: 20 minutes
# Directions
1. Brown the ground beef in a skillet, fry the bacon, and drain the fat.
2. Combine the beef, bacon bits, cooked macaroni, and cheddar cheese.
3. Place the combined filling onto the tortillas. *Add lettuce if desired*
#Cuisine/Fusion #Source/Tiktok #Course/Main #TypeOfFood/Wrap #Diet/Meat  