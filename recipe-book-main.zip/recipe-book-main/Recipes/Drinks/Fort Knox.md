# Ingredients
- 1 shot [[Gold Strike|gold strike]]
- [[Tonic]]
# Notes
- 1 servings
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains XX% ABV
# Directions
1. Pour the shot of gold strike.
2. Top up with tonic.
 #Source/Wikipedia #Course/Drink/Alcoholic #Course/Drink #Diet/Vegan  