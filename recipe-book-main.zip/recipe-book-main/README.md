Welcome to this recipe book. It is a compilation of recipes I found on the internet, in magazines, or other sources.
All sources are listed in tags at the bottom of the article.
Original recipes belong to LucyFeonix.

This repository, and all articles contained within it, are made for use with the note-taking app Obsidian, found here:
https://obsidian.md/
Presumably, all plugins should transfer with it. If not, the up-to-date list of plugins (read: the intended viewing experience) is as follows:
THEME:
Typomagical
PLUGINS:
Discord Rich Presence
Iconize (though this will not suddenly make icons appear, you will have to do that yourself)
Note Refactor
Novel Word Count
Recipe Grabber
Recipe View
Style Settings
Tag Wrangler

Please feel free to add pull requests for recipes, or corrections on ingredients and other issues with the repository. 

Enjoy :)
