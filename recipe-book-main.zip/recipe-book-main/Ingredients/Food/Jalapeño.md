*Jalapeño peppers* are a type of [[Chilli Pepper|chilli pepper]] hailing from Mexico. It is usually around 4000-8500 units on the Scoville scale. It is often picked while still green, but occasionally, it is allowed to ripen to red, orange or yellow hues. As a rule, the pepper gets sweeter and spicier the more it ripens.
Unripe jalapeños are noted to occasionally have sour notes, depending on the species.

It is also possible to obtain the peppers in pickled form, where the vinegar really brings out the flavours of the pepper.
The plant combines especially well with [[Cheese|cheese]], but it fits with any dish that could use a spicier kick to it.

#Ingredient