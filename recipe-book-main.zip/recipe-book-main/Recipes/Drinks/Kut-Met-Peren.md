# Ingredients
- 1 shot [[Tia Maria|tia maria]]
- 1 shot [[Pisang Ambon|pisang ambon]]
- [[Beer|beer]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 15.75% ABV
# Directions
1. Mix the Tia Maria and Pisang Ambon.
2. Top up with beer.
3. *Garnish with a pad, preferably with wings. Yes, that kind.*
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 