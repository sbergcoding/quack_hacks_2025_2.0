# Ingredients
- 2 tbsp [[Olive Oil|olive oil]]
- 600g italiaanse roerbakgroente
> [!question] wat zit hierin?
- 375g [[Vegetarian Mince|vegetarian mince]]
- 690g [[Passata Basilico|passata basilico]]
- 250g [[Pasta|lasagna sheets]]
- 175g [[Cheese|grated cheese]]
# Notes
- 3 people
- Requirements: 1 pan, 1 oven dish
- Time: ~50 minutes
# Directions
1. Heat the oil in a pan, and stirfry the vegetables for 3 minutes on medium heat.
2. Add the mince, and fry for another 2 minutes. 
3. Add the passata and cook on low for 15 minutes.
4. Preheat the oven to 200°C.
5. Put a scoop of sauce (the mixture from the previous steps) on the bottom of the oven dish, and then proceed to layer with lasagna sheets and sauce.
6. On top of the lasagna, add the cheese.
7. Put in the oven for 30 minutes.

#Cuisine/European/Italian #Course/Main #TypeOfFood/Lasagna #Diet/Vegetarian 