# Ingredients
- 2 shots [[Blue Curaçao|blue curaçao]]
- 1 shot [[Blueberry Liqueur|blueberry liqueur]]
- 2 shots [[Malibu Rum|malibu rum]]
- [[Sprite|Sprite]]
> [!note] You can also turn this into a Blåhaj Stronk by doubling the alcohol content.
# Notes
- 7 servings
- Requirements: [[Pitcher|pitcher]]
- Contains 2.35% ABV
# Directions
1. Mix the blue curaçao, blueberry liqueur and the malibu.
2. Top up with Sprite.
3. *Optionally, add 4 shark candy as garnish to the pitcher.*
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 
