# Ingredients
- 1/4 shot [[Passoã|passoa]]
- 1/4 shot [[Blue Curaçao|blue curaçao]]
- 1/4 shot [[Pisang Ambon|pisang ambon]]
- 1/4 shot [[Coebergh|coebergh]]
- [[Orange Juice|orange juice]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 2.16% ABV
# Directions
1. Mix the passoa, blue curaçao, pisang ambon and coebergh.
2. Top up with orange juice.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 