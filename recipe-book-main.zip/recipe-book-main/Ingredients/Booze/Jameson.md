- [ ] 
Jameson is an Irish blended whisky. The specific mix consists of several still- and grain whisky’s, which are thrice distilled afterwards.
The aroma of the whisky is flowery, with a woody influence. The sweetness of the flowers does not take the overtone, being overpowered by the herbal aftertaste, combined with vanilla and an underlying hint of [[Dry Sherry|sherry]].

Since the 1980s, Jameson Breweries has been in the hands of [[Pernod Ricard]], after which the quality supposedly dropped.
Jameson contains an ABV of 40%.

#Ingredient 