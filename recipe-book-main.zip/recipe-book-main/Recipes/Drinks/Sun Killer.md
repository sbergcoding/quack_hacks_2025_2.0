# Ingredients
- 1/2 shot [[Kontiki|kontiki]]
- 1/2 shot [[Malibu Rum|malibu rum]]
- 1 shot [[Tequila|tequila]]
- [[Sprite]]
# Notes
- 1 serving
- Requirements: [[Tumbler]]
- Contains 8.07% ABV
# Directions
1. Mix the kontiki, malibu rum, and tequila.
2. Top up with Sprite.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 