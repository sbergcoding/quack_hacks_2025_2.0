# Ingredients
- 3/4 shot [[Cointreau|cointreau]]
- 1/4 shot [[Jenever|ketel1]]
- [[Orange Juice|Orange juice]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 5.17% ABV
# Directions
1. Mix the cointreau and ketel1.
2. Top up with orange juice.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 