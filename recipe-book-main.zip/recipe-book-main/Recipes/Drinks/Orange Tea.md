# Ingredients
- 1 shot [[Orange Juice|orange juice]]
- 1 dash [[Monin Grenadine|monin grenadine]]
- [[Ice Tea Green|Ice tea green]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 0.0% ABV
# Directions
1. Mix the orange juice and monin grenadine.
2. Top up with ice tea green.
#Course/Drink #Course/Drink/Non-Alcoholic #Source/DeBolk #Diet/Vegan 