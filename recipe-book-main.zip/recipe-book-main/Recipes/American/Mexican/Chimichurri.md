# Ingredients
- 1 [[Red pepper|red pepper]]
- 1 [[Red Onion|red onion]]
- 15g [[Oregano|oregano]]
- 1 clove [[Garlic|garlic]]
- 15g [[Parsley|parsley]]
- 1 tsp [[Oregano|dried oregano]]
- 6 tbsp [[Olive Oil|olive oil]]
- 2 tbsp [[Red Wine Vinegar|red wine vinegar]]
# Notes
- X servings
- Requirements: mixer
- Time: 
> The chimichurri will keep for about two days, though it tastes best fresh.
# Directions
1. Cut the stem off of the red pepper. Halve it lengthwise, and remove the seeds. Cut up the meat.
2. Roughly dice the onions, and take the leaves off the fresh oregano.
3. Put all of the ingredients in a tall cup and blend it until the ingredients are still visible, but the mixture is stil homogenous.
#Cuisine/American/Mexican #Source/Allerande #Course/Sauce  #TypeOfFood/Sauce #Diet/Vegan  