These are the largest variety of [[Oyster Mushrooms|oyster mushrooms]]. They are noted for their thick, white stems, as well as their somewhat flat, golden brown caps. Their large size makes them a versatile pick - working well in pretty much any application. 
The king trumpet mushroom has a delicate, nutty flavour, as well as a firm, meaty texture. It is described as being similar to [[Scallop|scallops]], and can resemble these too, when cut crosswise. 
Due to the moisture content and solid stems, they are great for grilling, sautéing, or roasting.

To prepare these mushrooms, they should be brushed off or briefly rinsed off, and pat dry with a paper towel. The whole thing is edible, so the sky is the limit for these mushrooms when it comes to uses.

#Ingredient