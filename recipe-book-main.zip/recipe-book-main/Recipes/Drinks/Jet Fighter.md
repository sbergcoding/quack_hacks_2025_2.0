# Ingredients
- 1 shot [[Gin|gin]]
- [[Fanta]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains ?? ABV
# Directions
1. Pour the gin.
2. Top up with fanta.
#Course/Drink #Course/Drink/Alcoholic #Source/KarpeNoktem #Diet/Vegan 