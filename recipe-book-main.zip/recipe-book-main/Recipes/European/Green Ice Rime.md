# Ingredients
- 1/2 tsp [[Oil|oil]]
- 4 1/2 cups [[Milk|milk]]
- 3 tbsp [[Gelatin|gelatin]]
- 1/3 cup [[Granulated Sugar|granulated sugar]]
- 1 pinch [[Salt|salt]]
- 2 tsp [[Mint Extract|mint extract]]
- 1/4 tsp [[Vanilla Extract|vanilla extract]]
- 3 drops [[Food Colouring|green food colouring]]
# Notes
- 4 servings
- Requirements: baking dish
- Time: ±25 minutes work time, minimum 4 hours refrigerating time
# Directions
1. Using a paper towel, spread the oil in a square baking pan, coating the bottom and sides and leaving a slight film.
2. Pour 1/3 of the milk into a wide bowl, sprinkle the gelatin evenly over the surface and allow it to soften for about 10 minutes.
3. In a medium saucepan over medium heat, warm the remaining milk, the sugar, and the salt, stirring to dissolve the sugar. Remove from the heat, add the gelatin mixture, and whisk until the gelatin dissolves. Let cool for about 10 minutes.
4. Add the mint extract, vanilla, and food colouring, and stir to incorporate. Pour the mixture into the prepared baking dish and refrigerate until firm. (4 hours to 2 days)
5. When ready to serve, cut the gelatin into 2-inch squares and transfer to serving dish.
#Cuisine/Unknown #Source/DnD #Course/Dessert #TypeOfFood/Dessert #Diet/Meat/Gelatin  