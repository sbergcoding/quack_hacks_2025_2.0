---
aliases:
  - ladyfingers
  - lange vingers
---

*Savoiardi*, also known as ladyfingers, or lange vingers, are an egg-based, sweet, sponge cake biscuit, (roughly) shaped like large fingers. They are often used in Italian dessert recipes.
They traditionally do not contain any leavening agent, and rely on air incorporated in the egg for their spongey texture. 

#Ingredient 