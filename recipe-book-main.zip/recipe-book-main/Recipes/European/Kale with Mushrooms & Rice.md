# Ingredients
- 2 medium [[Yellow Onion|yellow onions]]
- 2 cloves [[Garlic|garlic]]
- 400g [[Button Mushrooms|button mushrooms]]
- 2 tbsp [[Olive Oil|olive oil]]
- 2 tsp [[Thyme|dried thyme]]
- 300g [[Rice|rice]]
- 150g [[Kale|kale]]
- 1 [[Vegetable stock|vegetable stock tablet]]
- 750ml water
- 50g [[Almonds|almonds]]
# Notes
- 3 people
- Requirements: 2 pans
- Time: 30 minutes
# Directions
1. Finely dice the onions and the garlic. Slice the mushrooms.
2. Heat the oil in a pan on medium heat and fry the onions, garlic, mushrooms and thyme for 5 minutes.
3. Add the rice, kale, and water, and crumble the stock tablet. Bring to a boil, and simmer (with the lid on the pan) for 15 minutes. Stir regularly.
4. Meanwhile, dry heat a frying pan and roast the almonds golden brown. Let cool and finely mince.
5. Sprinkle the rice dish with minced almonds, and add [[Black Pepper|pepper]] to taste.

#Cuisine/European #Course/Main #TypeOfFood/Rice #Diet/Vegetarian 