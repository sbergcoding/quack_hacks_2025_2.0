This cocktail was inspired by the two alcohols, which were the only ones present due to the Histos Sailing Competition of 1992. 
# Ingredients
- 1/3 shot [[Sippersbitter|sippersbitter]]
- 2/3 shot [[Beerenburg|beerenburg]]
# Notes
- 1 serving
- Requirements: [[Shot Glass|shot glass]]
- Contains 33.35% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 