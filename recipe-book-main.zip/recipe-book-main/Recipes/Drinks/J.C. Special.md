# Ingredients
- 1 shot [[Bacardi Blanca|Bacardi blanca]]
- 1 shot [[Hoppe Vieux|hoppe vieux]]
- 1/2 shot [[Gin|gin]]
- [[Sprite]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 12.17% ABV
# Directions
1. Mix the bacardi blanca, hoppe vieux, and gin.
2. Top up with sprite.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 