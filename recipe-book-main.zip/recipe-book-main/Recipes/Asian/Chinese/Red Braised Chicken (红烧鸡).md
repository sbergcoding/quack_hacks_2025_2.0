---
aliases:
  - Hong Shao Ji
  - 红烧鸡
---
# Ingredients
- 900g [[Chicken Thigh Fillet]]
- 1 tbsp [[Corn Starch|cornstarch]]
- 2 tbsp water
- 4 tbsp [[Oil|oil]]
- 25g [[Sugar|rock sugar]]
- 3 slices [[Ginger|ginger]]
- 1/4 cup [[Shaoxing Cooking Wine|shaoxing wine]]
- 2 tbsp [[Light Soy Sauce|light soy sauce]]
- 2 tsp [[Dark Soy Sauce|dark soy sauce]]
- 1 cup water
- *2 [[Scallions|scallions]] (chopped)*
# Notes
- 4 servings
- Requirements: Wok
- Time: 
# Directions
1. Cut the chicken into large chunks. Add the cornstarch and water. Mix well, coat the chicken evenly in the mixture. 
2. Mix in a quarter of the oil.
3. Preheat the wok until it starts to smoke lightly, and reduce the heat to low. Add the remaining oil along with the sugar. Let the sugar melt, while stirring. 
4. Increase the heat to medium-high, and add the chicken pieces in a single layer. Don't stir until the chicken pieces are lightly browned. Flip and repeat.
5. Reduce the heat to medium. Add the ginger, shaoxing wine, light soy sauce, dark soy sauce and water. Cover and simmer for 8-10 minutes.
> [!hint] If there is still a lot of liquid remaining after the 10 minutes, stir continuously until the liquid reduces to a rich sauce.
6. *Mix in the chopped scallion*, and serve.
#Cuisine/Asian/Chinese #Source/WoksOfLife #Course/Side #TypeOfFood/Chicken #Diet/Meat/Chicken 