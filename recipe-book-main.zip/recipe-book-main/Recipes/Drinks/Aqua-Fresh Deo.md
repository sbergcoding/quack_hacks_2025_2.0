# Ingredients
- 1 shot [[Blue Curaçao|blue curaçao]]
- 1 shot [[Vodka|vodka]]
- [[Orange Juice|orange juice]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 6.93% ABV
# Directions
1. Mix the blue curaçao and the vodka.
2. Top up with orange juice.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan  
