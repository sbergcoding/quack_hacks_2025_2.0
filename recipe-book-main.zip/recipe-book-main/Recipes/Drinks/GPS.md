# Ingredients
- 1 shot [[Gin|gin]]
- 1 shot [[Passoã|passoa]]
- 1 shot [[Safari|safari]]
# Notes
- 1 serving
- Requirements: [[Tumbler|tumbler]]
- Contains 24.13% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 