# Ingredients
- 6 oz high-quality [[Crab Meat|crabmeat]], drained
- 1 tbsp fresh [[Lemon|lemon juice]]
- 2 tsp finely grated lemon zest
- 1/2 tsp [[Salt|kosher salt]]
- [[Black Pepper|Black pepper]]
- 1/4 cup [[Crème Fraîche|crème fraîche]].
- 1/3 cup finely chopped [[Chives|fresh chives]]
- 2 [[Endives|endives]], root ends trimmed and larger leaves separated
# Notes
- 4 people
> [!todo] Requirements?
- Time: ±10 minutes?
# Directions
1. Blot the crabmeat dry with a paper towel, and pick over for shell fragments. 
2. Transfer to a small bowl, and add the lemon juice and 1/4 tsp of salt; add pepper, and stir to incorporate. 
3. Add the crème fraiche, lemon zest, the remaining 1/4 tsp salt, and most of the chives, and more pepper, and stir gently to mix.
4. Scoop about 1 tablespoon of the crab mixture into each of sixteen endive leaves, arrange them on a platter, and sprinkle with the remaining chives.
5. Serve immediately.

 #Cuisine/European #Source/DnD #Course/Side #TypeOfFood/Crab #Diet/Pescatarian