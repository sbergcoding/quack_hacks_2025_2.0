# Ingredients
- 1/2 shot [[Kontiki|kontiki]]
- 1/2 shot [[Vodka Red]]
- [[Sprite]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 2.8% ABV
# Directions
1. Mix the kontiki and red vodka.
2. Top up with Sprite.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 