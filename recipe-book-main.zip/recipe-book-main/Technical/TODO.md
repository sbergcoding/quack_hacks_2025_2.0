This is a list of recipes that I have not yet written out, but sound interesting or that I have simply not worked out yet. It is in no particular order.
[[Burek Sa Sirom]] - note: eastern yugoslav use more onion less meat, while western yugoslav use more meat less onion. Ruza makes one variant which is just cheese, and one variant which is just meat. Cheese with no onions, meat with onions. Can be left in the oven for a little longer than recommended - gets better the crunchier it is. More oily is traditional, but can be left out for health concerns.
[[Miso Imo]]
[[Singapore Mei Fun]]
[[Pico de Gallo]]
[[Mămăligă cu brânză și smântână]]
[[Chili Con Carne]]
https://www.howsweeteats.com/2020/05/baked-beans/
https://www.inspiredtaste.net/67523/grits-recipe/
https://www.allrecipes.com/recipe/51304/bills-sausage-gravy/
https://www.allrecipes.com/recipe/220943/chef-johns-buttermilk-biscuits/
https://www.lecremedelacrumb.com/best-super-moist-cornbread/
https://www.allrecipes.com/recipe/216888/good-new-orleans-creole-gumbo/
https://www.allrecipes.com/recipe/31848/jambalaya/
https://www.allrecipes.com/recipe/13041/my-best-clam-chowder/
