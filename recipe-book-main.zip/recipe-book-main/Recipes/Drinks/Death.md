# Ingredients
- 1/3 shot [[Tequila|tequila]]
- 1/3 shot [[Gold Strike|goldstrike]]
- 1/3 shot [[Sambuca|sambuca]]
- Drop of [[DropShot|dropshot]] or [[Salmari|salmari]]
# Notes
- 1 serving
- Requirements: [[Shot Glass|shot glass]]
- Contains ?? ABV.
# Directions
1. Mix the tequila, goldstrike, and sambuca.
2. Add a drop of dropshot.
#Course/Drink #Course/Drink/Alcoholic #Source/KarpeNoktem #Diet/Vegan 