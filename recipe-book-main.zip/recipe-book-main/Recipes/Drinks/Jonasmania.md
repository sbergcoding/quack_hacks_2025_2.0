# Ingredients
- 1/2 shot [[Coebergh|coebergh]]
- 1/2 shot [[Hail & Thunder|hail & thunder]]
- 1/3 shot [[Piña Colada|piña colada]]
- [[Apple Juice|Apple juice]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 3.29% ABV
# Directions
1. Mix the ingredients.
2. Shake well with ice, and stir into glass.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 