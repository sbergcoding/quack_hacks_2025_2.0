# Ingredients
- 1 shot [[Piña Colada|piña colada]]
- 1 shot [[Malibu Rum|malibu rum]]
- 1 shot [[Passoã|passoa]]
- 1 shot [[Jameson|jameson]]
- 1 shot [[Bacardi Black|Bacardi black]]
- [[Chocolate Milk|Chocolate milk]]
# Notes
- 1 serving
- Requirements: [[Beer Mug|beer mug]]
- Contains 10.31% ABV
# Directions
1. Mix the piña colada, rum, passoa, jameson, and bacardi black.
2. Top up with chocolate milk.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 