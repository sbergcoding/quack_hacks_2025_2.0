# Ingredients
- 1 shot [[Jameson|jameson]]
- 1 shot [[Hail & Thunder|hail & thunder]]
- 2 shots [[Fanta|fanta]]
# Notes
- 1 serving
- Requirements: [[Tumbler|tumbler]]
- Contains 16.25% ABV
# Directions 
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 