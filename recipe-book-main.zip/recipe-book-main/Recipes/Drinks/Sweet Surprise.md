# Ingredients
- 1 shot [[Tia Maria]]
- 1 shot [[Amaretto|amaretto]]
- 1/4 shot [[Cognac|cognac]]
- [[Chocolate Milk|Chocolate milk]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 7.73% ABV
# Directions
1. Mix the tia maria, amaretto, and cognac.
2. Top up with chocolate milk.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegetarian 