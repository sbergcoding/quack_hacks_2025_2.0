# Ingredients
- 2 lbs frozen pre-cooked [[Meatballs|meatballs]]
- 12 oz [[Chilli Sauce|chilli sauce]]
- 14 oz [[Jelleid Cranberry Sauce|jellied cranberry sauce]]
- 2 tbsp [[Orange Juice|orange juice]]
- 1 tbsp [[Brown Sugar|brown sugar]]
- *1 tbsp [[Parsley|parsley]], chopped*
# Notes
- 10 servings
- Requirements: [[Slow Cooker|slow cooker]], bowl
- Time: 4 hours 15 minutes
# Directions
1. Place the cranberry sauce in a bowl, and microwave at 45 second intervals until just melted.
2. Whisk in the chilli sauce, orange juice and brown sugar; stir until mostly smooth.
3. Place the meatballs in a slow cooker and pour the sauce over them.
4. Cook for 4 hours on low in a slow cooker, then serve, *garnished with parsley*.
#Cuisine/American/USA  #Source/DinnerAtTheZoo #Course/Appetizer #TypeOfFood/Meatballs #Diet/Meat  