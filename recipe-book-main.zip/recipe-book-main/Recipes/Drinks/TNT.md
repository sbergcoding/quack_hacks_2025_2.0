# Ingredients
- 1/2 shot [[Jameson|jameson]]
- 1/2 shot [[Pernod|pernod]] or [[Absinthe|absinthe]]
# Notes
- 1 serving
- Requirements: [[Tumbler|tumbler]]
- Contains 40.0% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 