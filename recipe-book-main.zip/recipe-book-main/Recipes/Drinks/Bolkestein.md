# Ingredients
- 1/2 shot [[Blue Curaçao|blue curaçao]]
- 1/2 shot [[Orange Bitters|orange bitters]]
# Notes
- 1 serving
- Requirements: [[Shot Glass|shot glass]]
- Contains 22.25% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan