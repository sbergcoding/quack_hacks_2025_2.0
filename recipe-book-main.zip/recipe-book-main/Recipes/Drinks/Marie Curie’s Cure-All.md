Putting this drink under a black light is recommended.
# Ingredients
- 1 shot [[Limoncello|limoncello]]
- 1/2 shot [[Blue Curaçao|blue curaçao]]
- [[Tonic|tonic]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 5.23% ABV
# Directions
1. Mix the limoncello and blue curaçao.
2. Top up with tonic.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 