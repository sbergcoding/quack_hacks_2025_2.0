# Ingredients
- 1/2 shot [[Apfelkorn|apfelkorn]]
- 1/4 shot [[Malibu Rum|malibu rum]]
- 1/4 shot [[Jägermeister|jägermeister]]
- [[Cola]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 2.83% ABV
# Directions 
1. Mix the apfelkorn, malibu, and jägermeister.
2. Top up with cola.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 