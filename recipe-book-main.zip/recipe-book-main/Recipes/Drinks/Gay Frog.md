# Ingredients
- 1 1/2 shot [[Sour Apple Liqueuer|sour apple liqueur]]
- 1 shot [[Tequila|tequila]]
- 1 shot [[Lime Juice|lime juice]]
- [[Sprite]]
# Notes
- 1 serving
- Requirements: [[Tumbler]]
- Contains 8.47% ABV
# Directions
1. Mix the sour apple liqueur, tequila, and lime juice.
2. Top up with sprite.
3. *Add a frog candy for garnish.*
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan #Diet/Vegetarian 
