This syrup has a thinner consistency than molasses and has a slightly sour taste. It is good for drizzling on top of cakes, biscuits or bread, and is good in marinades.

#Ingredient 

[[TODO]]