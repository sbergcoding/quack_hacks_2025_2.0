# Ingredients
- 1 shot [[Jenever]]
- [[Orange Juice|Orange juice]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 4.67% ABV
# Directions
1. Mix the ingredients.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 