# Ingredients
- 900g slab of [[Pork Belly|pork belly]]
- 3 bunches of [[Scallions|scallions]]
- 8 slices [[Fresh Ginger|ginger]]
- 2 cups [[Shaoxing Cooking Wine|shaoxing cooking wine]]
- 2/3 cup [[Light Soy Sauce|light soy sauce]]
- 2 1/2 tbsp [[Dark Soy Sauce|dark soy sauce]]
- 120g [[Sugar|rock sugar]]
# Notes
- 4 people
- Requirements: 1 pot
- Time: 4 hours
# Directions
1. Blanch the slab of pork belly in boiling water for 1 minute, and drain. Cut into 5x5cm pieces, and set aside.
2. In a medium-sized pot, lay scallions on the bottom in a thick, even layer. The scallions should cover the entire bottom of the pot. Lay the ginger slices over the scallions.
3. Lay the pork belly skin-side down on top of this layer.
4. Pour shaoxing wine, light soy sauce, and dark soy sauce over the meat, and add the rock sugar.
5. Cover the pot and place over medium high heat, and bring to a boil. Once boiling, turn down to low heat and simmer for 90 minutes.
6. Turn the belly skin-side up, and let simmer for another 90 minutes.

#Cuisine/Asian/Chinese #Course/Side #Diet/Meat/Pork 