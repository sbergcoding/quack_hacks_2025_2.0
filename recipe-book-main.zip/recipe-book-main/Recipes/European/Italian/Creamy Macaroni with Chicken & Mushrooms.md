# Ingredients
- 300 g [[Pasta|macaroni grande]]
- 2 tbsp [[Olive Oil|olive oil]]
- 300 g [[Minced Chicken|minced chicken]]
- 400 g Italiaanse roerbakgroente champignons
> [!todo] wat zit hierin? werk ingrediënten verder uit
- 200 g [[Garden Peas|garden peas]]
- 150 g [[Cream Cheese with Herbs|cream cheese with herbs]]
# Notes
- 3 people
- Requirements: 1 pot, 1 pan
- Time: ±30 minutes
# Directions
1. Cook the macaroni al dente according to package instructions.
2. Heat the oil in a pan and fry the chicken mince on medium-high heat. Add the [roerbakgroente] and garden peas and heat for 4 minutes.
3. Add the cream cheese and warm for 2 more minutes.
4. Add the macaroni and add salt and [[Black Pepper|pepper]] to taste.

#Cuisine/European/Italian #Course/Main #TypeOfFood/Pasta #Diet/Meat/Chicken  