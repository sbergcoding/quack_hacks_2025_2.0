Shallots are smaller, brown-skinned onions with purple flesh. They're pungent and garlicky, and have an intense flavour. They're easily minced and are splendid for use in salad dressings and sauces; and are good for roasting.

#Ingredient 

[[TODO]]