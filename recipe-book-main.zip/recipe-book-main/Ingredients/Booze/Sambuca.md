- [ ] 
*Sambuca* is a traditional Italian anise liqueur, often combined with [[coffee |coffee]], specifically [[Cappuccino|cappuccino]] or [[Espresso|espresso]]. It is noted to have sweet, liquorice-like tones. It is best drank [[Neat|neat]] with three coffee beans, but also works great in [[Mixed Drinks|mixed drink]] or [[Cocktails|cocktails]].

Sambuca contains an ABV of 40%.
#Ingredient