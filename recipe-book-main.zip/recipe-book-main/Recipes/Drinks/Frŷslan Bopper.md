# Ingredients
- 1/3 shot [[Sippersbitter|sippersbitter]]
- 1/3 shot [[Beerenburg|beerenburg]]
- 1/3 shot [[Jenever]]
# Notes
- 1 serving
- Requirements: [[Tumbler]]
- Contains 33.33% ABV
# Directions
1. Put a wet tumbler glass into the freezer for an hour.
2. Mix the ingredients, and put into the frozen glass.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 