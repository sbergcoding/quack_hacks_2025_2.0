Sweet onions are larger and slightly flatter than yellow onions, with less opaque skin. They're good for caramelizing, and are ideal for making [[Onion Rings|onion rings]]. They can be prepared in a multitude of ways.

#Ingredient 

[[TODO]]