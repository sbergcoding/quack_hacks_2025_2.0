---
aliases:
  - confectioner's sugar
  - powdered sugar
---

This has a more powdery texture that smoothly mixes into frostings or drinks. It contains and anti-caking agent such as [[Corn Starch|corn starch]] to prevent it from clumping.

#Ingredient 

[[TODO]]