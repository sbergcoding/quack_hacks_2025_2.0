# Ingredients
- 1 shot [[Vodka|vodka]]
- 2 shots [[Pisang Ambon|pisang ambon]]
- 2 shots [[Blue Curaçao|blue curaçao]]
- 5 shots [[Orange Juice|orange juice]]
# Notes
- 1 serving
- Requirements: [[Beer Mug|beer mug]]
- Contains 10.85% ABV
# Directions
1. Mix the ingredients.
#Course/Drink  #Course/Drink/Alcoholic  #Source/DeBolk  #Diet/Vegan 