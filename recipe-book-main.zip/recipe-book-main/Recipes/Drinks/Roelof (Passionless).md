# Ingredients
- 1/2 shot [[Apple Juice|apple juice]]
- 1/2 shot [[Orange Juice|orange juice]]
- 1 bottle [[AA Sports Drink|aa sports drink]]
# Notes
- 1 serving
- Requirements: [[Beer Mug|beer mug]]
- Contains 0.0% ABV
# Directions
1. Mix the ingredients
#Course/Drink #Course/Drink/Non-Alcoholic #Source/DeBolk #Diet/Vegan 