# Ingredients
- 1 shot [[Kontiki|kontiki]]
- 1 shot [[Pisang Ambon|pisang ambon]]
- [[Tonic|tonic]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 6.00% ABV
# Directions
1. Mix the kontiki and pisang ambon.
2. Top up with tonic.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 
