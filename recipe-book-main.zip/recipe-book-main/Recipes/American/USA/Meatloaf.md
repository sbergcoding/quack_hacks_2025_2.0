# Ingredients
- 1 1/2 lbs [[Minced Mea|minced meat]]
- 1 [[Egg|egg]]
- 1 [[Onion]|onion]], chopped
- 1 cup [[Milk|milk]]
- 1 cup [[Bread Crumbs|bread crumbs]]
- 1/3 cup [[Ketchup|ketchup]]
- 2 tbsp [[Brown Sugar|brown sugar]]
- 2 tbsp [[Mustard|mustard]]
# Notes
- 4 servings
- Requirements: 1 hour & 10 minutes
- Time: Oven, loaf pan
# Directions
1. Preheat the oven to 175’C. Grease a loaf pan.
2. Combine the minced meat, onion, milk, bread crumbs and egg in a large bowl; season with [[Salt|salt]] and [[Black Pepper|pepper]]. Transfer into prepared loaf pan.
3. Mix ketchup, brown sugar, and mustard together in a small bowl until combined. Pour over the meatloaf evenly.
4. Bake in the oven until no longer pink in the centre - about 1 hour.
#Cuisine/American/USA #Source/AllRecipes #Course/Side #TypeOfFood/Meat #Diet/Meat 