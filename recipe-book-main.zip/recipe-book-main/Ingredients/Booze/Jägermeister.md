*Jägermeister* is a herbal bitter from Germany, that is often used as a digestif or as a mixer.
Traditionally, it is also used as a panacea. 
Classically, it is drank pure, but it is popularly also used as a mixer, in, for example, a [[Jägerbomb]].

Jägermeister contains an ABV of 35%.

#Ingredient 