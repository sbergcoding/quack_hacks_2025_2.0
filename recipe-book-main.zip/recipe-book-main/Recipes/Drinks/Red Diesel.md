# Ingredients
- 1/2 shot [[Apfelkorn|apfelkorn]]
- 1/2 shot [[Passoã|passoa]]
- 1/2 shot [[Grand Marnier|grand marnier]]
- 1/2 shot [[Tequila|tequila]]
# Notes
- 1 serving
- Requirements: [[Tumbler|tumbler]]
- Contains 26.85% ABV
# Directions
1. Mix the ingredients in a shaker, add ice, and shake.
2. Strain into a longdrink glass.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 