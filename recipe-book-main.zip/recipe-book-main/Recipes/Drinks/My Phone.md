# Ingredients
- 1 shot [[Stroh-80|stroh-80]]
- 1/2 shot [[Gin|gin]]
- [[Ginger Ale|Ginger ale]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 13.17% ABV
# Directions
1. Mix the stroh-80 and gin.
2. Top up with ginger ale.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 
