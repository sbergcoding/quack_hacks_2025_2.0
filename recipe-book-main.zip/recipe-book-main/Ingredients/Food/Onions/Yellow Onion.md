---
aliases:
  - onion
---

*Yellow onions* are the everyday onion, and are assumed to be what is used if nothing else is specified. It's got brown skin and white flesh, and smells strongly. They can be prepared in a multitude of ways:

#Ingredient 

[[TODO]]