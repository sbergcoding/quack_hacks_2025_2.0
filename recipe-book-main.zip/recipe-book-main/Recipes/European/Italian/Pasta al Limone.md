# Ingredients
- 160g [[Pasta|pasta]]
- 60g [[Cheese|parmesan cheese]] (grated)
- 30g [[Butter|butter]]
- 1 clove [[Garlic|garlic]] (minced)
- 1 [[Lemon|lemon]]
- *3 tbsp [[Cooking Cream|cooking cream]]*
- Fresh [[Sweet Basil|basil]]
# Notes
- 2 servings
- Requirements:
- Time: 
# Directions
1. Cook the pasta al dente according to package instructions.
2. Meanwhile, zest and juice the lemon.
3. Take a frying pan and melt the butter over medium heat. Fruit the garlic for a minute, and lower the heat. Add the lemon zest and keep the heat low until the pasta is done.
4. Drain the pasta, and add to the molten butter, and mix. Add the lemon juice, and mix. *Add the cooking cream*.
5. Turn off the heat, and add the parmesan and basil, along with [[Salt|salt]] and [[Black Pepper|pepper]]. 
#Cuisine/European/Italian #Source/Smaakmenutie #Course/Main #TypeOfFood/Pasta #Diet/Vegan #Diet/Vegetarian 
> [!tip] Preferably serve with a salad or a meat side. It's not that much by itself.
l