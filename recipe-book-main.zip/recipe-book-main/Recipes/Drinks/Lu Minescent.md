# Ingredients
- 1/2 shot [[Kontiki|kontiki]]
- 1/2 shot [[Safari|safari]]
- [[Orange Juice|orange juice]]
# Notes
- 1 serving
- Requirements: [[Tumbler|tumbler]]
- Contains 2.93% ABV
# Directions
1. Mix the kontiki and the safari.
2. Top up with orange juice.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 
