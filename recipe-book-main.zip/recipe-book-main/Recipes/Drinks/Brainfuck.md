# Ingredients
- 1/2 shot [[Peach Tree|peach tree]]
- 1/2 shot [[Sperm|sperm]]
- 1 tsp [[Simple Syrup|simple syrup]]
# Notes
- 1 serving
- Requirements: [[Shot Glass|shot glass]], at least 1 willing man
- Contains 17.5% ABV
# Directions
1. Mix the peach tree and the sperm in the shot glass.
2. Top up with simple syrup.
3. Pray.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegetarian 