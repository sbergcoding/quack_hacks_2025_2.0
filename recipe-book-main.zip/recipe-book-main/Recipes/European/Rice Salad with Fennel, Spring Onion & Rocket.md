# Ingredients
- 300g [[Rice|rice]]
- 50g [[Raisins|raisins]]
- 3 [[Red Onion|red onions]]
- 5 [[Scallions|spring onions]]
- 1 [[Fennel|fennel bulb]]
- 50g [[Almonds|almonds]]
- 20g [[Parsley|parsley]]
- 85g [[Rocket|rocket]]
- 2 tbsp [[Apple Cider Vinegar|apple cider vinegar]]
# Notes
- 3 people
- Requirements: 1 pot, 1 pan
- Time: 30 minutes
# Directions
1. Heat half of the oil in a pan and fry the red onions (and the white part of the spring onions) for 5 minutes on medium high heat.
2. Turn the heat down to low and let simmer for 10 minutes. Add [[Salt|salt]] and [[Black Pepper|pepper]] to taste.
3. Halve the fennel and remove the hard core. Cut the bulb into very thin slices.
4. Roughly chop the almonds, cut the spring onion into thin rings and finely chop the parsley.
5. Mix the fried onion, fennel, rocket, vinegar, spring onion and the remaining oil into one large bowl. 
6. Sprinkle with almonds and parsley.
#Cuisine/European #Course/Side #TypeOfFood/Salad #Diet/Vegetarian 