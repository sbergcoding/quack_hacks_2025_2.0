# Ingredients
- 30g [[Cheese|parmesan cheese (grated)]]
> [!note] *Nutritional yeast also possible*
- 30g [[Sweet Basil|fresh basil]]
- 2 tbsp [[Pine Tree Nuts|roast pine tree nuts]] / [[Walnuts|walnuts]]
- 2 cloves [[Garlic|garlic (minced)]]
- ~75 ml [[Olive Oil|olive oil]]

# Notes
- Feeds up to 3
- Requirements: Mortar & Pestle
- Time: 10 minutes

# Directions
1. Add all the dry ingredients to the mortar & pestle. Grind until it is a fine paste.
2. Add olive oil and salt to bind the mixture together. Grind until mixed thoroughly.

#Cuisine/European/Italian #Course/Sauce  #Diet/Vegan  