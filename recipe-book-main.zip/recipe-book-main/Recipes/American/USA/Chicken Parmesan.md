# Ingredients
- 4 [[Chicken Thigh Fillet|chicken thighs]]
- 1 [[Yellow Onion|yellow onion]]
- 250g [[Button Mushrooms|button mushrooms]]
- 4 cloves [[Garlic|garlic]]
- 500ml [[Chicken Broth|chicken broth]]
- 250ml [[Cooking Cream|cooking cream]]
- 250g [[Pasta|pasta]]
- 135g [[Cheese|parmesan cheese]]
- 15g [[Parsley|parsley]], minced
> [!note] If for whatever reason you do not want to use cooking cream, this can be substituted by 250ml of chicken broth and ±30g of [[Butter|unsalted butter]]. Might have to fudge the cooking times a bit.
# Notes
- 3 servings
- Requirements: 
- Time: 
# Directions
1. Flavour the chicken thighs with salt and [[Black Pepper|pepper]]. Mince the onion and slice the mushrooms.
2. Heat 1 1/2 tbsp oil in a pan, and fry the onion until glassy. Press the garlic, and add to the onion along with the mushrooms. Cook the mixture for two minutes.
3. Add the chicken stock, the cooking cream, and some salt and pepper. Add the pasta, and turn the fire to low. Simmer for 15 minutes, until the pasta is al dente.
4. Stir the parmesan through the pasta until it melts. 
5. Heat a spoo of olive oil in a frying pan and fry the chicken on both sides for about 2-3 minutes per side, until they are golden brown. Cut into strips, and divide over the pasta.
6. Garnish with parsley and extra parmesan.
#Cuisine/American/USA #Source/24Kitchen #Course/Main #TypeOfFood/Pasta #Diet/Meat/Chicken 