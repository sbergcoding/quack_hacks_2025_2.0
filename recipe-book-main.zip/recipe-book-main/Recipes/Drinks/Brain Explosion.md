# Ingredients
- 1/2 shot [[Peach Tree|peach tree]]
- 1/2 shot [[Baileys|baileys]]
- 1 tsp [[Simple Syrup|simple syrup]]
# Notes
- 1 serving
- Requirements: [[Shot Glass|shot glass]] or [[Tumbler|tumbler]]
- Contains 18.5% ABV
# Directions
1. Mix the peach tree and the baileys in the shot glass.
2. Top up with simple syrup.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegetarian