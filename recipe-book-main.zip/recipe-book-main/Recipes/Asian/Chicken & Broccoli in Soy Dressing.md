# Ingredients
- 350g [[Chicken Thigh Fillet|chicken thighs]]
- 1 lime / 1 tbsp [[Lime Juice|lime juice]]
- 1 bushel [[Scallions|scallions]]
- 2 cloves [[Garlic|garlic (minced)]]
- 1 [[Yellow Onion|yellow onion]] or 2 [[Shallot|shallots]]
- 1 [[Red Pepper|red pepper]]
- 2 tbsp [[Ketjap Manis|ketjap manis]]
- 2 tbsp [[Light Soy Sauce|light soy sauce]]
- 1 tbsp [[Ginger Syrup|ginger syrup]]
- ±175g [[Rice|rice]]
# Notes
- Serves 2
- Time: 30 minutes
- Requirements: 2 pans
# Directions
1. Thoroughly mix the ketjap, soy sauce, garlic, red pepper, lime juice, and the ginger syrup.
2. Dice the thighs and mix with the dressing.
3. Prepare the rice to package instructions.
4. Cut the broccoli flowers off the stem, and cut the stem into cubes. Cook these for ±4.5 minutes.
5. Fruit the minced shallot/onion for about a minute in some oil. Add the chicken and dressing and fry until a golden brown, taking care to stir.
6. Add the broccoli to the chicken.
7. *Garnish with spring onion, an extra red pepper, and a slice of lime.*

#Cuisine/Asian #Course/Main #TypeOfFood/Rice #Diet/Meat/Chicken 