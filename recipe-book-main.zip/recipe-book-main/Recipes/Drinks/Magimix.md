# Ingredients
- 1 shot [[Vodka|vodka]]
- [[Cola]]
- [[Fanta]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 5% ABV
# Directions
1. Pour the vodka into the glass.
2. Simultaneously pour in the cola and fanta.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 