# Ingredients
- 1/2 shot [[Grand Marnier|grand marnier]]
- 1/2 shot [[Stroh-80|stroh-80]]
- [[Tabasco]]
# Notes
- 1 serving
- Requirements: [[Shot Glass|shot glass]]
- Contains 60.0% ABV
# Directions
1. Mix the grand marnier and stroh-80.
2. Add a couple of drops of tabasco.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 