# Ingredients
- 1 cup unsalted [[Butter|butter]]
- 1 tbsp minced [[Garlic]]
- 1/4 cup [[Cheese|parmesan]]
- 1 tsp [[Garlic Salt|garlic salt]]
- 1 tsp [[Italian Seasoning|italian seasoning]]
- 1/2 tsp [[Black Pepper|ground black pepper]]
- 1/4 tsp [[paprika|paprika]]
# Notes
- 16 servings
- Requirements: Bowl
- Time: ~30 minutes
# Directions
1. Soften the butter. 
> [!tip] You can easily do this by heating water in the microwave for 2 minutes on high, and then warming the butter afterwards with the ambient heat.
2. Mix all the ingredients in a bowl. Set to chill for 20 minutes.
#Cuisine/Fusion #Source/AllRecipes #Course/Ingredient #TypeOfFood/Spread #Diet/Vegetarian  