# Ingredients
- 2 boneless [[Chicken Breast|chicken breasts]]
- 1 [[Yellow Onion|yellow onion]]
- 1 tsp [[Salt|salt]]
- 18 white [[Corn Tortilla|corn tortillas]]
- 3 cups [[Salsa Verde|salsa verde]]
- 1 cup crumbled [[Cheese|queso fresco]]
- [[Sour Cream|Sour cream]]
- [[Cilantro]]

> [!question]
> What is queso fresco? 

> [!todo]
> convert american units to metric

# Requirements
> [!todo]
> - Time?
> - Servings?
> - Pots/pans?

# Instructions
1. Preheat oven to 400F
2. Place the chicken breasts in a stock pot along with 1/2 an onion and salt and cover with water. Bring to a boil and simmer until cooked through.
3. Remove chicken from the water and let cool slightly. Shred chicken with two forks, and set aside.
4. Mince the remaining onion, and add to the shredded chicken.
5. In batches, place 6 tortillas on a microwave safe dish, and microwave 40 to 50 seconds to make them pliable and less liable to crack. Keep them covered by  dish cloth to stay warm, then working one by one dip each warm tortilla in green salsa. Scoop two rounded tablespoons into each tortilla and roll tightly and place in a large casserole dish, seam side down, in a single layer. Repeat with the remaining tortillas and chicken.
6. Drench entire pan with 1 cup sauce and sprinkle with crumbled queso fresco.
7. Bake, covered in oven for 25 to 30 minutes. Remove from oven and serve with sour cream or additional queso fresco, if desired.

#Cuisine/American/Mexican #Course/Main #TypeOfFood/Enchiladas #Diet/Meat/Chicken  