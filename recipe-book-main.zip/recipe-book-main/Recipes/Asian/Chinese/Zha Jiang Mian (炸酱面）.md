# Ingredients
- 3/4 lbs [[Minced Meat|minced pork]]
- 3 tbsp [[Neutral Oil|neutral oil]]
- 2 tbsp [[Garlic|garlic]] (minced)
- 1 tbsp [[Ginger|ginger]] (mixed)
- 3 [[Scallions|scallions]] (sliced)
- 1/4 cup [[Shaoxing Cooking Wine|shaoxing wine]]
- 2 tsp [[Granulated Sugar|sugar]]
- [[Noodles|noodles]]
- 5 tbsp [[Ground Soybean Sauce|ground soybean sauce]]
- 1/4 cup [[Sweet Bean Sauce|sweet bean sauce]]
- 1 tbsp [[Light Soy Sauce|light soy sauce]]
- 1/2 tsp [[Dark Soy Sauce|dark soy sauce]]
- 1/4 cup water
# Notes
- 2 servings
- Requirements: wok, pot, bowl
- Time: 25 minutes
# Directions
1. Mince the garlic and ginger, and thinly slice the scallions. Save a little bit of the green portion for garnish.
2. Combine the ground soybean sauce, sweet bean sauce, light soy sauce, dark soy sauce and water in a bowl.
3. Heat oil in a wok on medium heat and cook the pork until the water has evaporated and the fat starts to brown the meat (6-8 min)
4. Add the garlic, ginger, and scallion to the pork, and sauté until fragrant.
5. Add the shaoxing wine, stir, and let evaporate. Once most of the wine has evaporated, add in the sauce.
6. Bring to a simmer, and sweeten with sugar. Cook until slightly thickened. (6-8 min)
7. Boil noodles 1 minute less than package instructions.
8. Serve in a bowl. Make sure not to add too much sauce, as it may be too salty.
#Cuisine/Asian/Chinese #Source/Tiktok #Course/Main #TypeOfFood/Noodles #Diet/Meat/Pork  