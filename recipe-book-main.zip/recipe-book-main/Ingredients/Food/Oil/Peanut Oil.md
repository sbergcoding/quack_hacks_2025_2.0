Great for frying and stir-frying, has a neutral or slightly nutty flavour. Best used in moderation.

- Good for stir-frying and sautéing

#Ingredient 

[[TODO]]