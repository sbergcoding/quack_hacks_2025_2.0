- [ ] 
*Gold Strike* is a Dutch liquor, consisting mainly of [[Cinnamon|cinnamon]]. 
While it is possible to drink the alcohol [[Neat|neat]], it mostly lends itself to [[Mixed Drinks|mixed drinks]] and [[Cocktails|cocktails]]. 

Gold strike contains an ABV of 50%.
A lesser variant of this drink is [[Silver Strike|silver strike]].

#Ingredient 