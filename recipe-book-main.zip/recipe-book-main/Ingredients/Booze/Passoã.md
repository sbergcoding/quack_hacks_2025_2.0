*Passoã* is a [[Passionfruit|passionfruit]]-based liquor. It is often used in combination with fruit juices, as it complements them well. Its taste is mostly sweet, as it only contains water, [[Sugar|sugar]] and alcohol, with passionfruit juices only making up 2% of the volume.

Due to Dutch supermarket rules, regular passoã is not allowed to be sold in supermarkets. To get around this, Passoã Festa exists, which has an ABV of 14.9% - 0.1% under the legal limit.

(Regular) Passoã contains an ABV of 17%.

#Ingredient 