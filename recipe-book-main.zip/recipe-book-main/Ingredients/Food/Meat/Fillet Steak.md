---
aliases:
  - kogelbiefstuk
  - fillet steak
---
[[TODO]]