*Coconut oil* is an [[Oil|oil]] that predictably comes from the coconut. It is high in saturated fats, making it very stable. It is usually solid at room temperature - a quality used for many no-bake desserts.
Unrefined coconut oil has a strong coconut flavour, and a smoke point of about 280F. The terms virgin and extra virgin are unregulated, and can thus be used interchangeably to refer to unrefined oil.
When refined, however, it is flavourless, and it has a high smoke point of 365F. 

Due to the solid nature, it can sometimes serve as as substitute for [[Butter|butter]]. However, care should be taken to only use about 3/4 of what is originally called for - as coconut oil contains more fat solid. 
#Ingredient 
