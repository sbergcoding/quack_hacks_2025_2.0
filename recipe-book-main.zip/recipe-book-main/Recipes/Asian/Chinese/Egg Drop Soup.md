  # Ingredients
- 4 cups [[Chicken Broth]]
- 1/2 tsp [[Sesame Oil|sesame oil]]
- 3/4 tsp [[Salt|salt]]
- 1/8 tsp [[Sugar|sugar]]
- 1/8 tsp [[White Pepper|white pepper]]
- *1/2 tsp [[Turmeric|turmeric]]*
- 3 tbsp [[Corn Starch Slurry|cornstarch slurry]]
- 3 [[Egg|eggs]] (lightly beaten)
- *1 [[Scallions|scallion]] (chopped)*
- 1/4 tsp [[MSG]]
# Notes
- 6(?) servings
- Requirements: Soup pot
- Time: 15 minutes
# Directions
1. Bring the chicken stock to a simmer in a medium soup pot. Stir in the sesame oil, salt, sugar, white pepper, MSG, *and turmeric.*
2. Add the cornstarch slurry.
> [!warning] Stir continuously while adding the cornstarch slurry. Otherwise, you'll get clumps of it in the soup.
3. Slowly drizzle in the egg.  Stir it slowly if you want large swirls of egg, or faster for smaller swirls. 
4. Ladle into bowls and serve, *garnished with scallion*.
#Cuisine/Asian/Chinese #Source/WoksOfLife #Course/Starter #TypeOfFood/Soup #Diet/Vegetarian  