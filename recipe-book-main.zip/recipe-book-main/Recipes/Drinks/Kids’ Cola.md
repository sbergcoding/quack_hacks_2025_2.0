# Ingredients
- 2 shots [[Stroh-80]]
- [[Cola]]
# Notes
- 1 serving
- Requirements: [[Longdrink Glass|longdrink glass]]
- Contains 21.33% ABV
# Directions
1. Pour the stroh-80 into a glass of cola.
#Course/Drink #Course/Drink/Alcoholic #Source/DeBolk #Diet/Vegan 